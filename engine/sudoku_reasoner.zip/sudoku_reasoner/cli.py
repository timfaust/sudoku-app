"""Command line interface for human-oriented Sudoku analysis."""
from __future__ import annotations

import argparse
import sys
from typing import Sequence

from .core.model import Fact
from .core.reasoning import ExactOneReasoner
from .core.verify import exact_solutions
from .ideas import IDEAS
from .sudoku import Grid, SudokuGame
from .sudoku.effort import SINGLE
from .sudoku.path import CEILING, HumanPath, human_path

DEFAULT_PUZZLE = "005000000090803000001200536060300000203000801000008090186004900000901040000000600"


def puzzle(text: str) -> Grid:
    try:
        return SudokuGame.parse(text)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(str(exc)) from exc


def ceiling(text: str) -> int:
    try:
        value = int(text)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"invalid integer: {text!r}") from exc
    if value <= SINGLE:
        raise argparse.ArgumentTypeError(f"must be at least {SINGLE + 1}")
    return value


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Analyze Sudoku with generic exact-one proofs "
                                "(`python -m sudoku_reasoner app` runs the app, "
                                "`python -m sudoku_reasoner generate` makes puzzles, "
                                "`python -m sudoku_reasoner site OUT` builds the static site)")
    p.add_argument("--puzzle", type=puzzle, default=puzzle(DEFAULT_PUZZLE), help="81 digits/dots; whitespace allowed")
    p.add_argument("--max-effort", type=ceiling, default=CEILING,
                   help="stop before a round that costs more (default %(default)s, the rating's resolution)")
    p.add_argument("--moves", action="store_true", help="list the moves of each round")
    p.add_argument("--open", action="store_true", help="then open the app on this puzzle")
    return p.parse_args(argv)


def describe_fact(game: SudokuGame, fact: Fact) -> str:
    row, col, digit = game.decode(fact.atom)
    return f"r{row + 1}c{col + 1}{'=' if fact.value else '≠'}{digit}"


def print_moves(game: SudokuGame, path: HumanPath) -> None:
    for number, found in enumerate(path.rounds, 1):
        print(f"\nRound {number}, effort {found.burden}, {found.looks:.1f} looks "
              f"(steps start in {found.starts} of {found.places} places):")
        for move in found.moves:
            facts = " ".join(describe_fact(game, fact) for fact in move.conclusions)
            print(f"  {type(move.explanation).__name__:<15} {facts}")


def level(text: str) -> int:
    try:
        value = int(text)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"invalid integer: {text!r}") from exc
    if not 1 <= value <= CEILING:
        raise argparse.ArgumentTypeError(f"must be from 1 to {CEILING}")
    return value


def generate_main(argv: Sequence[str]) -> int:
    """Make puzzles of a level, one line each: the puzzle, its level, search and givens."""
    from .service import generate

    p = argparse.ArgumentParser(prog="python -m sudoku_reasoner generate", description=generate_main.__doc__)
    p.add_argument("--level", type=level, required=True, help=f"the level, 1 to {CEILING}")
    p.add_argument("--count", type=int, default=1, help="how many puzzles (default %(default)s)")
    p.add_argument("--search", choices=("any", "less", "more"), default="any",
                   help="ask for less or more search, which takes longer (default %(default)s)")
    p.add_argument("--idea", choices=("any", *IDEAS), default="any",
                   help="a key idea whose step cracks the puzzle at its level (default %(default)s)")
    p.add_argument("--seed", type=int, help="the first seed, so a run repeats (puzzle i uses seed + i)")
    args = p.parse_args(argv)
    for i in range(args.count):
        seed = None if args.seed is None else args.seed + i
        try:
            made = next(event for event in generate(args.level, seed, args.search, args.idea) if event["type"] == "made")
        except ValueError as exc:  # an idea that cannot crack the level (generate.climb)
            p.error(str(exc))
        r = made["rating"]
        print(f"{r['puzzle']}  level {r['level']}, search {r['search']:.0f}, {r['givens']} givens, {made['tried']} tried", flush=True)
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else list(argv)
    if argv[:1] == ["app"]:
        from .app import main as app_main

        return app_main(argv[1:])
    if argv[:1] == ["generate"]:
        return generate_main(argv[1:])
    if argv[:1] == ["site"]:
        from .site import main as site_main

        return site_main(argv[1:])
    args = parse_args(argv)
    game = SudokuGame(args.puzzle)
    reasoner = ExactOneReasoner(game.problem)
    print("Initial Sudoku:\n")
    print(game.format(reasoner.initial()))
    path = human_path(game, max_effort=args.max_effort)
    profile = path.profile
    if args.moves:
        print_moves(game, path)
    stall = f"stopped at the effort ceiling {args.max_effort}" if profile.limited else "stalled beyond the proof language"
    print(f"\nHuman path: {'solved' if profile.solved else stall} in {len(path.rounds)} rounds")
    after = f", then a round above {args.max_effort}" if profile.limited else " or more"
    print(f"Level: {profile.level}{'' if profile.solved else after}")
    print(f"Search: {profile.search:.1f} looks")
    print("Rounds by effort: " + ", ".join(f"{effort}: {count}" for effort, count in profile.rounds))
    solutions = exact_solutions(reasoner, reasoner.initial(), limit=2)
    print(f"Exact verification: {'unique solution' if len(solutions) == 1 else 'multiple solutions' if solutions else 'no solution'}")
    if solutions:
        print("\nExact solution:\n")
        print(game.format(solutions[0]))
    if args.open:
        from .app import main as app_main

        return app_main(["--puzzle", "".join(str(v) for row in game.grid for v in row)])
    return 0

"""Exact verification: depth-first search over exact-one choices.

Separate from human analysis and never one of its premises.
"""
from __future__ import annotations

from random import Random

from .model import Fact, State
from .reasoning import ExactOneReasoner


def exact_solutions(reasoner: ExactOneReasoner, state: State, *, limit: int = 2, rng: Random | None = None) -> list[State]:
    """Up to ``limit`` solutions reachable from ``state``, in a deterministic
    order, or in one shuffled by ``rng`` (a random solution, for the generator)."""
    out: list[State] = []

    def visit(current: State) -> None:
        current = reasoner.closure(current)
        if reasoner.contradiction(current):
            return
        if reasoner.solved(current):
            out.append(current)
            return
        groups = reasoner.groups(current, reasoner.problem.atom_count)
        if not groups:
            return
        _, atoms = groups[0]
        if rng is not None:
            atoms = rng.sample(atoms, len(atoms))
        for atom in atoms:
            visit(reasoner.apply(current, Fact(atom, True)))
            if len(out) >= limit:
                return

    visit(state)
    return out

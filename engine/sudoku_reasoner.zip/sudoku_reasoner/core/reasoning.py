"""Exact-one proofs: singles, case proofs and covers (CONCEPT.md §2).

No Sudoku knowledge lives here. A case proof starts from one exhaustive choice,
follows forced singles in each branch, and charges only the causal prefix its
conclusion needs, over every subset-minimal support (exact, D32).
"""
from __future__ import annotations

from collections import deque
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from itertools import permutations
from typing import NamedTuple

from .model import Branch, Fact, Problem, Proof, Relation, Size, State, bits

Catalogue = dict[Fact, tuple[Proof | Relation, ...]]  # each conclusion with its proofs


class _Cost(NamedTuple):
    """One way to derive a fact inside a branch: the positive atoms it needs
    (``support``, ``size`` of them) and its longest chain. Ordered best first."""

    size: int
    span: int
    support: int


Front = tuple[_Cost, ...]  # an antichain of costs, best first
_FREE = (_Cost(0, 0, 0),)


@dataclass(frozen=True, slots=True)
class _BranchClosure:
    assumption: int
    end: State
    positive: dict[int, Front]
    negative: dict[int, Front]
    contradiction: Front


class ExactOneReasoner:
    def __init__(self, problem: Problem) -> None:
        self.problem = problem
        self.masks = tuple(sum(1 << a for a in c.atoms) for c in problem.constraints)
        self.memberships = problem.memberships
        self.families = tuple(sorted({c.family for c in problem.constraints}))
        # Per family: its constraint ids, and the one holding each atom.
        self.family_constraints = {
            f: tuple(cid for cid, c in enumerate(problem.constraints) if c.family == f) for f in self.families
        }
        self.family_of = {
            f: {atom: cid for cid in cids for atom in problem.constraints[cid].atoms}
            for f, cids in self.family_constraints.items()
        }
        self.all_atoms = (1 << problem.atom_count) - 1
        # Caches live and die with this reasoner (one analysis).
        self._coherence_cache: dict[int, int] = {}
        self._apply_cache: dict[tuple[State, Fact], State] = {}
        self._empty_cache: dict[State, int | None] = {}
        self._forced_cache: dict[State, tuple[tuple[Fact, int], ...]] = {}
        self._groups_cache: dict[tuple[State, int], tuple[tuple[int, tuple[int, ...]], ...]] = {}
        self._closure_cache: dict[tuple[State, int, int], _BranchClosure] = {}
        self._covers_cache: dict[State, tuple[Relation, ...]] = {}

    def coherence(self, atoms: int) -> int:
        """``Problem.coherence``, cached."""
        cached = self._coherence_cache.get(atoms)
        if cached is None:
            cached = self._coherence_cache[atoms] = self.problem.coherence(atoms)
        return cached

    def blank(self) -> State:
        return State(self.all_atoms, 0)

    def initial(self) -> State:
        state = self.blank()
        for atom in self.problem.givens:
            state = self.apply(state, Fact(atom, True))
        return state

    def apply(self, state: State, fact: Fact) -> State:
        key = (state, fact)
        cached = self._apply_cache.get(key)
        if cached is not None:
            return cached
        bit = 1 << fact.atom
        if not fact.value:
            out = State(state.possible & ~bit, state.true)
        else:
            # A placement eliminates its peers even when it is itself already
            # eliminated, so placements commute.
            possible = state.possible
            for cid in self.memberships[fact.atom]:
                possible &= ~(self.masks[cid] & ~bit)
            out = State(possible, state.true | bit)
        self._apply_cache[key] = out
        return out

    def excluders(self, state: State, atom: int) -> list[int]:
        """The atoms held true that share a constraint with ``atom``: the
        placements that rule it out."""
        bit = 1 << atom
        true = 0
        for cid in self.memberships[atom]:
            true |= state.true & self.masks[cid] & ~bit
        return list(bits(true))

    def apply_all(self, state: State, facts: Iterable[Fact]) -> State:
        for fact in facts:
            state = self.apply(state, fact)
        return state

    def empty_constraint(self, state: State) -> int | None:
        """The first constraint with no option left, or None: every clash leaves one."""
        if state not in self._empty_cache:
            self._empty_cache[state] = next((cid for cid, mask in enumerate(self.masks) if not state.possible & mask), None)
        return self._empty_cache[state]

    def contradiction(self, state: State) -> bool:
        return self.empty_constraint(state) is not None

    def solved(self, state: State) -> bool:
        return not self.contradiction(state) and all(state.true & mask for mask in self.masks)

    def settled(self, state: State) -> bool:
        """Contradictory or solved: no proof has anything left to conclude."""
        return self.contradiction(state) or self.solved(state)

    def open_constraints(self, state: State) -> tuple[int, ...]:
        """The constraints without a true atom yet."""
        return tuple(cid for cid, mask in enumerate(self.masks) if not state.true & mask)

    def with_options(self, state: State, options: int) -> tuple[int, ...]:
        """The open constraints left with exactly ``options`` (a nonempty mask)."""
        atom = (options & -options).bit_length() - 1
        return tuple(cid for cid in self.memberships[atom]
                     if state.possible & self.masks[cid] == options and not state.true & self.masks[cid])

    def forced(self, state: State) -> tuple[tuple[Fact, int], ...]:
        """Each single with its lowest forcing constraint."""
        cached = self._forced_cache.get(state)
        if cached is not None:
            return cached
        found: dict[int, int] = {}
        for cid, mask in enumerate(self.masks):
            if state.true & mask:
                continue
            options = state.possible & mask
            if options.bit_count() == 1:
                found.setdefault(next(bits(options)), cid)
        cached = self._forced_cache[state] = tuple(
            (Fact(atom, True), cid) for atom, cid in sorted(found.items(), key=lambda x: (x[1], x[0]))
        )
        return cached

    def groups(self, state: State, max_width: int) -> tuple[tuple[int, tuple[int, ...]], ...]:
        """The open constraints with 2 to ``max_width`` options, one per option set."""
        key = (state, max_width)
        cached = self._groups_cache.get(key)
        if cached is not None:
            return cached
        unique: dict[tuple[int, ...], int] = {}
        for cid, mask in enumerate(self.masks):
            if state.true & mask:
                continue
            atoms = tuple(bits(state.possible & mask))
            if 2 <= len(atoms) <= max_width:
                unique.setdefault(atoms, cid)
        cached = self._groups_cache[key] = tuple(
            sorted(((cid, atoms) for atoms, cid in unique.items()), key=lambda x: (len(x[1]), x[0]))
        )
        return cached

    def covers(self, state: State) -> tuple[Relation, ...]:
        """Every connected rank-0 relation of at most ``Problem.max_cover`` bases
        that eliminates something; complete and monotone (CONCEPT.md §2, Covers).

        Bases are unsolved constraints; each base added shares a cover with the
        bases before it, so only connected relations are built.
        """
        cached = self._covers_cache.get(state)
        if cached is not None:
            return cached
        max_size = self.problem.max_cover
        live = state.possible & ~state.true
        found: dict[tuple[int, int], Relation] = {}
        for base_family, cover_family in permutations(self.families, 2):
            index = self.family_of[cover_family]
            options: dict[int, int] = {}
            touched: dict[int, int] = {}  # base -> mask of cover ids its options lie in
            for cid in self.family_constraints[base_family]:
                mine = live & self.masks[cid]
                if state.true & self.masks[cid] or not mine:
                    continue
                spread = 0
                for atom in bits(mine):
                    spread |= 1 << index[atom]
                if spread.bit_count() <= max_size:
                    options[cid], touched[cid] = mine, spread
            by_cover: dict[int, list[int]] = {}
            for cid, spread in touched.items():
                for cover in bits(spread):
                    by_cover.setdefault(cover, []).append(cid)

            seen: set[int] = set()
            stack = [(1 << cid, spread) for cid, spread in touched.items()]
            while stack:
                chosen, spread = stack.pop()
                if chosen in seen:
                    continue
                seen.add(chosen)
                size = chosen.bit_count()
                if size == spread.bit_count():
                    inside = 0
                    for cid in bits(chosen):
                        inside |= options[cid]
                    covered = 0
                    for cover in bits(spread):
                        covered |= self.masks[cover]
                    if eliminated := covered & live & ~inside:
                        found.setdefault((chosen, spread), Relation(tuple(bits(chosen)), tuple(bits(spread)), eliminated))
                if size == max_size:
                    continue
                for cover in bits(spread):
                    for cid in by_cover[cover]:
                        if not chosen >> cid & 1 and (spread | touched[cid]).bit_count() <= max_size:
                            stack.append((chosen | 1 << cid, spread | touched[cid]))
        cached = self._covers_cache[state] = tuple(found.values())
        return cached

    def _single(self, state: State, fact: Fact, cid: int) -> Proof:
        return Proof((fact,), state, self.apply(state, fact), cid, (), Size(1, 1, 1, 1))

    def closure(self, state: State) -> State:
        """Apply forced singles until none is left or a contradiction appears."""
        while not self.contradiction(state):
            forced = self.forced(state)
            if not forced:
                break
            for fact, _ in forced:
                state = self.apply(state, fact)
        return state

    def _saturate(self, state: State) -> State:
        """Apply forced singles in waves to a fixpoint, past contradictions (D35),
        so a false branch's facts do not depend on which wave fails first."""
        while forced := self.forced(state):
            state = self.apply_all(state, (fact for fact, _ in forced))
        return state

    @staticmethod
    def _insert(fronts: dict[int, Front], atom: int, cost: _Cost) -> bool:
        """Add ``cost`` to the atom's front unless dominated; report a change.

        A cost dominates when its support is a subset and its span no longer.
        Sizes alone would not do: a larger support can share more atoms with
        the supports it is combined with.
        """
        front = fronts.get(atom, ())
        support, span = cost.support, cost.span
        for old in front:
            if not old.support & ~support and old.span <= span:
                return False
        fronts[atom] = tuple(sorted([*(old for old in front if support & ~old.support or span > old.span), cost]))
        return True

    @staticmethod
    def _combined(fronts: Sequence[Front], add: int, step: int, budget: int) -> list[_Cost]:
        """Every undominated combination of one cost per front within ``budget``
        support atoms, folding the fronts in one at a time (dominance survives
        any completion). Premises with the same front choose together."""
        partial = [(add, 0)]
        for front in sorted(dict.fromkeys(fronts), key=len):
            spans: dict[int, int] = {}
            for support, span in partial:
                for cost in front:
                    union = support | cost.support
                    if union.bit_count() <= budget:
                        longest = max(span, cost.span)
                        if spans.get(union, longest + 1) > longest:
                            spans[union] = longest
            partial = []
            for union, span in sorted(spans.items(), key=lambda item: item[0].bit_count()):
                if not any(not old & ~union and old_span <= span for old, old_span in partial):
                    partial.append((union, span))
            if not partial:
                return []
        return [_Cost(support.bit_count(), step + span, support) for support, span in partial]

    @staticmethod
    def _within(fronts: Sequence[Front], room: int) -> list[tuple[_Cost, ...]]:
        """Every choice of one cost per front whose supports hold at most ``room``
        atoms together, in front order."""
        out: list[tuple[_Cost, ...]] = []

        def walk(i: int, chosen: tuple[_Cost, ...], union: int) -> None:
            if i == len(fronts):
                out.append(chosen)
                return
            for cost in fronts[i]:
                joined = union | cost.support
                if joined.bit_count() <= room:
                    walk(i + 1, (*chosen, cost), joined)

        walk(0, (), 0)
        return out

    def _branch_closure(self, parent: State, assumption: int, budget: int) -> _BranchClosure:
        key = (parent, assumption, budget)
        cached = self._closure_cache.get(key)
        if cached is None:
            if len(self._closure_cache) >= 8192:  # bounded: closures are the large entries
                del self._closure_cache[next(iter(self._closure_cache))]
            cached = self._closure_cache[key] = self._compute_branch_closure(parent, assumption, budget)
        return cached

    def _compute_branch_closure(self, parent: State, assumption: int, budget: int) -> _BranchClosure:
        """Pareto fronts of supports, within ``budget`` atoms, for every fact the
        branch derives and for its contradiction. Facts of the parent are free."""
        end = self._saturate(self.apply(parent, Fact(assumption, True)))
        placed = end.true & ~parent.true & ~(1 << assumption)
        eliminated = parent.possible & ~end.possible
        pos: dict[int, Front] = {assumption: _FREE}
        neg: dict[int, Front] = {}

        def negative(atom: int) -> Front | None:
            return neg.get(atom) if parent.possible >> atom & 1 else _FREE

        # Semi-naive: a cost is propagated once, when it enters a front.
        pending: dict[tuple[bool, int], list[_Cost]] = {}
        queue: deque[tuple[bool, int]] = deque()

        def add(is_positive: bool, atom: int, cost: _Cost) -> None:
            if self._insert(pos if is_positive else neg, atom, cost):
                key = (is_positive, atom)
                if key not in pending:
                    pending[key] = []
                    queue.append(key)
                pending[key].append(cost)

        def derive(target: int, cid: int, atom: int = -1, new: Front = ()) -> None:
            premises = [new if other == atom else negative(other) for other in self.problem.constraints[cid].atoms if other != target]
            if None not in premises:
                for cost in self._combined(premises, 1 << target, 1, budget):
                    add(True, target, cost)

        pending[True, assumption] = list(_FREE)
        queue.append((True, assumption))
        for target in bits(placed):
            for cid in self.memberships[target]:
                derive(target, cid)
        while queue:
            is_positive, atom = key = queue.popleft()
            front = (pos if is_positive else neg)[atom]
            new = tuple(cost for cost in pending.pop(key) if cost in front)
            for cid in self.memberships[atom]:
                if is_positive:
                    for other in bits(self.masks[cid] & eliminated & ~(1 << atom)):
                        for cost in new:
                            add(False, other, cost)
                else:
                    for target in bits(self.masks[cid] & placed):
                        derive(target, cid, atom, new)

        witnesses: dict[int, Front] = {}
        for mask in self.masks:
            if not end.possible & mask:
                premises = [negative(a) for a in bits(mask)]
                if None not in premises:
                    for cost in self._combined(premises, 0, 0, budget):
                        self._insert(witnesses, -1, cost)

        return _BranchClosure(assumption, end, pos, neg, witnesses.get(-1, ()))

    def _branch(self, parent: State, assumption: int, support: int, contradiction: bool) -> Branch:
        """The branch replayed: the singles that place ``support``. Every kept
        support replays (CONCEPT.md, Appendix); that is measured, not proven, so
        it is checked."""
        current = self.apply(parent, Fact(assumption, True))
        remaining = set(bits(support))
        steps: list[Proof] = []
        while remaining:
            available = [(fact, cid) for fact, cid in self.forced(current) if fact.atom in remaining]
            assert available, "a kept support does not replay (CONCEPT.md, Appendix)"
            fact, cid = min(available, key=lambda x: x[0].atom)  # replay order: presentation only
            steps.append(self._single(current, fact, cid))
            current = steps[-1].end
            remaining.remove(fact.atom)
        assert not contradiction or self.contradiction(current), "a kept contradiction does not replay"
        return Branch(assumption, tuple(steps), current, contradiction)

    def _group_proofs(self, state: State, cid: int, atoms: tuple[int, ...], held: int) -> list[Proof]:
        width = len(atoms)
        # A branch's support is part of the atoms the proof holds.
        closures = [self._branch_closure(state, atom, held - width) for atom in atoms]

        candidates: set[Fact] = set()
        for closure in closures:
            candidates.update(Fact(a, True) for a in closure.positive if not (state.true & (1 << a)))
            candidates.update(Fact(a, False) for a in closure.negative if state.possible & (1 << a))

        split = sum(1 << a for a in atoms)
        proofs: list[Proof] = []
        for fact in candidates:
            # Per branch, the front of deriving the fact or a contradiction.
            fronts: list[Front] = []
            derived: list[Front] = []
            for closure in closures:
                found = (closure.positive if fact.value else closure.negative).get(fact.atom, ())
                derived.append(found)
                options = {0: closure.contradiction} if closure.contradiction else {}
                for cost in found:
                    self._insert(options, 0, cost)
                if not options:
                    break
                fronts.append(options[0])
            if len(fronts) < width:
                continue

            # Every Pareto-optimal variant over (work, span, coherence of the
            # held atoms and the fact, atoms held) within ``held`` atoms: the
            # limit removes a down-set of this order, so it keeps exactly the
            # unlimited search's variants that hold so few (CONCEPT.md, Appendix).
            variants: list[tuple[tuple[int, int, int, int], tuple[_Cost, ...]]] = []
            for choice in self._within(fronts, held - width):
                union = 0
                for cost in choice:
                    union |= cost.support
                total_work = width + sum(cost.size for cost in choice)
                key = (total_work, 1 + max(cost.span for cost in choice), self.coherence(split | union | 1 << fact.atom), union.bit_count())
                if not any(old != key and all(a <= b for a, b in zip(old, key)) for old, _ in variants):
                    variants = [(old, c) for old, c in variants if not (old != key and all(a <= b for a, b in zip(key, old)))]
                    variants.append((key, choice))

            for (total_work, span, _, union_size), choice in variants:
                branches = tuple(
                    self._branch(state, closure.assumption, cost.support, cost not in found)
                    for closure, found, cost in zip(closures, derived, choice)
                )
                proofs.append(Proof(
                    (fact,), state, self.apply(state, fact), cid, branches, Size(width, span, total_work, width + union_size),
                ))
        return proofs

    def _refutations(self, state: State, held: int) -> list[Proof]:
        """The choice {Z, not Z} of each live atom whose Z branch fails: a proof of
        not Z at width 2 (D42)."""
        proofs: list[Proof] = []
        if held < 2:
            return proofs
        for atom in bits(state.possible & ~state.true):
            fact = Fact(atom, False)
            for cost in self._branch_closure(state, atom, held - 2).contradiction:
                branch = self._branch(state, atom, cost.support, True)
                size = Size(2, 1 + cost.span, 2 + cost.size, 2 + cost.size)
                proofs.append(Proof((fact,), state, self.apply(state, fact), None, (branch,), size))
        return proofs

    @staticmethod
    def _by_fact(proofs: Iterable[Proof]) -> dict[Fact, tuple[Proof, ...]]:
        out: dict[Fact, list[Proof]] = {}
        for proof in proofs:
            out.setdefault(proof.facts[0], []).append(proof)
        return {fact: tuple(found) for fact, found in out.items()}

    def singles(self, state: State) -> dict[Fact, tuple[Proof, ...]]:
        """The direct proofs: every constraint left with one option."""
        if self.settled(state):
            return {}
        return self._by_fact(self._single(state, fact, cid) for fact, cid in self.forced(state))

    def eliminations(self, state: State) -> dict[Fact, tuple[Relation, ...]]:
        """Each elimination of a cover relation, with every relation that makes it."""
        out: dict[Fact, tuple[Relation, ...]] = {}
        if self.settled(state):
            return out
        for relation in self.covers(state):
            for atom in bits(relation.eliminates):
                out[Fact(atom, False)] = out.get(Fact(atom, False), ()) + (relation,)
        return out

    def cases(self, state: State, *, max_held: int) -> dict[Fact, tuple[Proof, ...]]:
        """The case proofs holding at most ``max_held`` atoms (``Size.held``), of
        every constraint's options and every refutation, with no limit on work:
        exactly the unlimited catalogue's proofs that hold so few (CONCEPT.md,
        Appendix)."""
        if max_held < 1:
            raise ValueError("max_held must be positive")
        if self.settled(state):
            return {}
        return self._by_fact((
            *(proof for cid, atoms in self.groups(state, max_held)
              for proof in self._group_proofs(state, cid, atoms, max_held)),
            *self._refutations(state, max_held),
        ))

    def unbounded(self, state: State) -> tuple[int, int]:
        """The (placed, eliminated) masks some case split of any size proves, read
        from the branches' singles closures: exact and cheap. Refutations need no
        pass: a split on any of Z's constraints proves not Z too."""
        placed = eliminated = 0
        if self.settled(state):
            return placed, eliminated
        for _, atoms in self.groups(state, self.problem.atom_count):
            true, possible = -1, 0
            for atom in atoms:
                end = self.closure(self.apply(state, Fact(atom, True)))
                if not self.contradiction(end):
                    true &= end.true
                    possible |= end.possible
            if true != -1:
                placed |= true & ~state.true
                eliminated |= state.possible & ~possible
        return placed, eliminated

    def catalogue(self, state: State, *, max_held: int) -> Catalogue:
        """Every proof of every conclusion holding at most ``max_held`` atoms: the
        singles, the case proofs and the covers' eliminations."""
        out: Catalogue = {}
        for part in (self.singles(state), self.cases(state, max_held=max_held), self.eliminations(state)):
            for fact, proofs in part.items():
                out[fact] = out.get(fact, ()) + proofs
        return out

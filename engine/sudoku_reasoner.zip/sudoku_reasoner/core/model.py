"""Small data model for exact-one reasoning."""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from itertools import combinations
from typing import Iterator

Atom = int


def bits(mask: int) -> Iterator[int]:
    """Yield the atom ids set in ``mask``, lowest first."""
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask ^= bit


@dataclass(frozen=True, slots=True)
class Constraint:
    atoms: tuple[Atom, ...]
    family: int = 0  # constraints of one family partition the atoms (e.g. all cells)


@dataclass(frozen=True, slots=True)
class Problem:
    atom_count: int
    constraints: tuple[Constraint, ...]
    givens: tuple[Atom, ...] = ()
    memberships: tuple[tuple[int, ...], ...] = field(init=False, repr=False, compare=False)  # per atom, ascending
    partitions: tuple[tuple[int, ...], ...] = field(init=False, repr=False, compare=False)  # block masks
    max_cover: int = field(init=False, repr=False, compare=False)  # most bases a cover relation needs (D33)

    def __post_init__(self) -> None:
        if self.atom_count < 1:
            raise ValueError("atom_count must be positive")
        for c in self.constraints:
            if not c.atoms or len(c.atoms) != len(set(c.atoms)):
                raise ValueError("constraints must contain distinct atoms")
            if any(a < 0 or a >= self.atom_count for a in c.atoms):
                raise ValueError("constraint atom out of range")
        if any(a < 0 or a >= self.atom_count for a in self.givens):
            raise ValueError("given atom out of range")
        memberships: list[list[int]] = [[] for _ in range(self.atom_count)]
        for cid, c in enumerate(self.constraints):
            for atom in c.atoms:
                memberships[atom].append(cid)
        object.__setattr__(self, "memberships", tuple(tuple(cids) for cids in memberships))
        partitions, max_cover = self._partitions()
        object.__setattr__(self, "partitions", partitions)
        object.__setattr__(self, "max_cover", max_cover)

    def _partitions(self) -> tuple[tuple[tuple[int, ...], ...], int]:
        """Block masks of every non-trivial partition joined from two families
        (two atoms share a block when constraints of the pair connect them), and
        half the most constraints of one family in a block: 4 in Sudoku."""
        out = set()
        max_cover = 0
        for pair in combinations(sorted({c.family for c in self.constraints}), 2):
            parent = list(range(self.atom_count))

            def root(atom: int) -> int:
                while parent[atom] != atom:
                    parent[atom] = parent[parent[atom]]
                    atom = parent[atom]
                return atom

            for c in self.constraints:
                if c.family in pair:
                    for atom in c.atoms[1:]:
                        parent[root(atom)] = root(c.atoms[0])
            blocks: dict[int, int] = {}
            for atom in range(self.atom_count):
                blocks[root(atom)] = blocks.get(root(atom), 0) | 1 << atom
            if len(blocks) > 1:
                out.add(tuple(sorted(blocks.values())))
            for family in pair:
                per_block = Counter(root(c.atoms[0]) for c in self.constraints if c.family == family)
                max_cover = max(max_cover, max(per_block.values()) // 2)
        return tuple(sorted(out)), max_cover

    def focus_blocks(self, atoms: int) -> tuple[tuple[int, ...], ...]:
        """For each partition holding the atoms in the fewest blocks, the blocks
        it touches: where to look (a row, column, box or digit in Sudoku)."""
        touched = [tuple(block for block in blocks if atoms & block) for blocks in self.partitions]
        least = min((len(found) for found in touched), default=0)
        return tuple(dict.fromkeys(found for found in touched if len(found) == least))

    def coherence(self, atoms: int) -> int:
        """The fewest blocks of one family-pair partition that hold the atoms: in
        Sudoku the fewest digits, rows, columns or boxes (CONCEPT.md §1)."""
        return min(
            (sum(1 for block in blocks if atoms & block) for blocks in self.partitions),
            default=min(atoms.bit_count(), 1),
        )


@dataclass(frozen=True, slots=True)
class State:
    possible: int
    true: int

    def shows(self, fact: Fact) -> bool:
        """Whether the fact is already decided here: placed, or eliminated."""
        bit = 1 << fact.atom
        return bool(self.true & bit) if fact.value else not self.possible & bit


@dataclass(frozen=True, slots=True)
class Fact:
    atom: Atom
    value: bool


@dataclass(frozen=True, slots=True)
class Size:
    """Structural size of a proof."""

    width: int  # alternatives in the starting choice; a single is 1
    span: int   # longest necessary implication chain
    work: int   # assumptions + deductions across all branches
    held: int   # distinct atoms held true: assumptions and placements, each counted once


@dataclass(frozen=True, slots=True)
class Branch:
    assumption: Atom
    steps: tuple["Proof", ...]
    end: State
    contradiction: bool = False


@dataclass(frozen=True, slots=True)
class Proof:
    facts: tuple[Fact, ...]
    start: State
    end: State
    # The forcing constraint of a direct proof, or a case proof's exhaustive choice:
    # a constraint's options, or None for one atom's {Z, not Z} (a refutation).
    constraint: int | None
    branches: tuple[Branch, ...]
    size: Size

    @property
    def is_direct(self) -> bool:
        return not self.branches


@dataclass(frozen=True, slots=True)
class Relation:
    """A rank-0 cover relation, a proof of its eliminations (D33): the options of
    k base constraints of one family lie in k cover constraints of another, so
    the covers' other options are false (CONCEPT.md §2, Covers)."""

    bases: tuple[int, ...]
    covers: tuple[int, ...]
    eliminates: int  # live options of the covers outside the bases

"""Puzzles of a chosen level, made by the verifier and rated by the human path
(D54, D65; APP_CONCEPT.md §4).

A start is a random solution carved to a symmetric minimal puzzle: givens are
removed in pairs, symmetric under a half turn, in random order, while the
solution stays unique (the verifier's question, never the rating's). Most such
puzzles are easy, so the generator then climbs: it puts one removed pair back,
carves again, and keeps the new puzzle when it is solved at a level no lower and
no higher than the target. A climb that has tried as many puzzles as there are
pairs without rising, so that each pair could have come back once, is on a
plateau of its solution and starts again from a new one. Asked for less or
more search, the profile's second number (CONCEPT.md §5), it goes on at the
level the same way, keeping each puzzle with less (or more) search than the one
it stands on, until it is on a plateau again. Asked for a key idea (D73), it is at
the level only when a step of that idea cracks it there, and walks on at the level
until one does or it is on a plateau. Every puzzle it keeps is rated, unique
and solved by the engine, so every hint and explanation reaches the end of it.

The rating runs with the target as its ceiling (D58): a round above the target
is never worked out, and a ceiling changes no round below it, so the made
puzzle's rounds are the rating's own. Outside the rating's hash: the generator
is a client of the rating, not part of it.
"""
from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass
from random import Random

from .core.reasoning import ExactOneReasoner
from .core.verify import exact_solutions
from .ideas import LEVELS, key_ideas
from .sudoku.effort import SINGLE
from .sudoku.game import SudokuGame
from .sudoku.path import CEILING, HumanPath, human_path

PAIRS = tuple((cell, 80 - cell) for cell in range(41))  # a half turn; the centre is its own pair
EMPTY = SudokuGame(SudokuGame.parse("0" * 81))
_SOLVER = ExactOneReasoner(EMPTY.problem)


def text(grid: list[int]) -> str:
    return "".join(map(str, grid))


def _game(grid: list[int]) -> SudokuGame:
    return SudokuGame(tuple(tuple(grid[row * 9:row * 9 + 9]) for row in range(9)))


def unique(grid: list[int]) -> bool:
    reasoner = ExactOneReasoner(_game(grid).problem)
    return len(exact_solutions(reasoner, reasoner.initial(), limit=2)) == 1


def solution(rng: Random) -> list[int]:
    """A random solution grid: the verifier's search in a shuffled order."""
    return list(EMPTY.board(exact_solutions(_SOLVER, _SOLVER.initial(), limit=1, rng=rng)[0]))


def carve(grid: list[int], rng: Random, *, last: tuple[int, int] | None = None) -> list[int]:
    """Remove pairs of givens in random order while the solution stays unique;
    ``last``, a pair just put back, is tried last, so the result is minimal."""
    out = list(grid)
    order = [pair for pair in PAIRS if out[pair[0]] and pair != last]
    rng.shuffle(order)
    for a, b in order + ([last] if last and out[last[0]] else []):
        kept = out[a], out[b]
        out[a] = out[b] = 0
        if not unique(out):
            out[a], out[b] = kept
    return out


def rate(grid: list[int], level: int) -> HumanPath:
    """The human path with the target as its ceiling (at least a single's next effort)."""
    return human_path(_game(grid), max_effort=max(level, SINGLE + 1))


@dataclass(frozen=True, slots=True)
class Tried:
    """A puzzle tried and not kept; ``tried`` counts every puzzle rated so far."""

    tried: int


@dataclass(frozen=True, slots=True)
class Climbed:
    """A puzzle the climb stands on now, with its rating."""

    tried: int
    puzzle: str
    path: HumanPath


@dataclass(frozen=True, slots=True)
class Made(Climbed):
    """The climb's last word: the puzzle it stands on, at the target level."""


def _fits(path: HumanPath, level: int) -> bool:
    return path.profile.solved and path.profile.level <= level


def _neighbour(puzzle: list[int], answer: list[int], level: int, rng: Random) -> tuple[list[int], HumanPath | None]:
    """One removed pair put back and the puzzle carved again, rated unless it
    is the same puzzle."""
    pair = rng.choice([pair for pair in PAIRS if not puzzle[pair[0]]])
    grown = list(puzzle)
    for cell in pair:
        grown[cell] = answer[cell]
    candidate = carve(grown, rng, last=pair)
    return candidate, rate(candidate, level) if candidate != puzzle else None


def _there(path: HumanPath, level: int, idea: str | None) -> bool:
    """Solved at the level, where a step of ``idea`` cracks it when one is asked."""
    return path.profile.solved and path.profile.level == level and (idea is None or idea in key_ideas(path.rounds, level))


def climb(level: int, rng: Random, *, search: int = 0, idea: str | None = None) -> Iterator[Tried | Climbed]:
    """Puzzles on the way to ``level``, one per try, then the one made there;
    ``search`` -1 or 1 asks for less or more search, 0 for any; ``idea`` the
    key idea (ideas.IDEAS), None for any."""
    if type(level) is not int or not 1 <= level <= CEILING:
        raise ValueError(f"a level is a whole number from 1 to {CEILING}")
    if search not in (-1, 0, 1):
        raise ValueError("search is -1 (less), 0 (any) or 1 (more)")
    if idea is not None and level not in LEVELS.get(idea, ()):
        raise ValueError(f"no puzzle of level {level} is cracked by {idea!r}")
    tried = 0
    while True:
        answer = solution(rng)
        puzzle = carve(answer, rng)
        tried += 1
        path = rate(puzzle, level)
        if not _fits(path, level):
            yield Tried(tried)
            continue
        yield Climbed(tried, text(puzzle), path)
        risen = tried  # when the climb last rose
        while not _there(path, level, idea) and tried - risen < len(PAIRS):
            candidate, found = _neighbour(puzzle, answer, level, rng)
            tried += 1
            if found and _fits(found, level) and found.profile.level >= path.profile.level:
                if found.profile.level > path.profile.level:
                    risen = tried
                puzzle, path = candidate, found
                yield Climbed(tried, text(puzzle), path)
            else:
                yield Tried(tried)
        if _there(path, level, idea):
            break
    moved = tried  # when the search last moved
    while search and tried - moved < len(PAIRS):
        candidate, found = _neighbour(puzzle, answer, level, rng)
        tried += 1
        if found and _there(found, level, idea) and search * (found.profile.search - path.profile.search) > 0:
            puzzle, path, moved = candidate, found, tried
            yield Climbed(tried, text(puzzle), path)
        else:
            yield Tried(tried)
    yield Made(tried, text(puzzle), path)

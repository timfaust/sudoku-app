"""The app's engine service: pure functions, JSON in and out (D48).

Everything the app shows about a puzzle comes from here; the UI never analyses
anything itself (D49). The functions are stateless, so the same calls run behind
the local server (``app.py``) and in the browser's Web Worker under Pyodide
(``web/js/worker.js``), both through ``CALLS`` and ``run``.

Encoding: a move names its ``idea``, one of the four every explanation reads as
(APP_CONCEPT.md §2): ``single`` (one option left), ``count`` (a cover), ``fail``
(a refutation) or ``cases`` (a case split with a choice). A fact is ``{"cell",
"digit", "value"}`` (cells 0-80 row by row, digits
1-9, value true for a placement); a constraint is ``{"kind", "index", "digit"}``
(``kind`` cell, row, column or box) or null for a refutation's choice {Z, not Z};
a board is ``{"grid", "candidates"}`` (81 digits, 0 for empty, and each empty
cell's candidates). A case split's branch lists, for its assumption and each
step, the candidates it ``removes``.
"""
from __future__ import annotations

import json
from collections.abc import Callable, Iterator, Sequence
from random import Random

from . import generate as generator
from .core.model import Branch, Fact, Proof, State, bits
from .core.reasoning import ExactOneReasoner
from .core.verify import exact_solutions
from .ideas import IDEAS, LEVELS, idea
from .sudoku.canon import minlex, scramble
from .sudoku.explain import CaseSplit, Cover, Explanation, ImplicationMap, Single
from .sudoku.game import SudokuGame
from .sudoku.moves import Move
from .sudoku.path import (
    CEILING, DifficultyProfile, Round, Rounds, Searching, Stop, candidate_levels, cheapest, search_round,
)

KIND = {Single: "single", Cover: "cover", ImplicationMap: "map", CaseSplit: "case"}


class Encoder:
    """JSON for the engine's objects, for one puzzle."""

    def __init__(self, game: SudokuGame, reasoner: ExactOneReasoner) -> None:
        self.game = game
        self.reasoner = reasoner

    def fact(self, fact: Fact) -> dict:
        r, c, d = self.game.decode(fact.atom)
        return {"cell": r * 9 + c, "digit": d, "value": fact.value}

    def constraint(self, cid: int | None) -> dict | None:
        if cid is None:  # a refutation's choice {Z, not Z}
            return None
        meta = self.game.constraint_meta[cid]
        return {"kind": meta.kind, "index": meta.index, "digit": meta.digit}

    def witness(self, state: State) -> dict | None:
        """The constraint left without options in a contradictory state."""
        return self.constraint(self.reasoner.empty_constraint(state))

    def removed(self, before: State, after: State) -> list[dict]:
        """The candidates a step removes, so that a client can replay a branch
        without propagating anything itself (D49)."""
        out = []
        for atom in bits(before.possible & ~after.possible):
            r, c, d = self.game.decode(atom)
            out.append({"cell": r * 9 + c, "digit": d})
        return out

    def branch(self, start: State, branch: Branch) -> dict:
        assumed = branch.steps[0].start if branch.steps else branch.end
        return {
            "assumption": self.fact(Fact(branch.assumption, True)),
            "removes": self.removed(start, assumed),
            "contradiction": branch.contradiction,
            "witness": self.witness(branch.end) if branch.contradiction else None,
            "steps": [{"fact": self.fact(step.facts[0]), "source": self.constraint(step.constraint),
                       "removes": self.removed(step.start, step.end)} for step in branch.steps],
        }

    def branches(self, proof: Proof) -> list[dict]:
        return [self.branch(proof.start, branch) for branch in proof.branches]

    def explanation(self, explanation: Explanation) -> dict:
        if isinstance(explanation, Single):
            return {"source": self.constraint(explanation.constraint)}
        if isinstance(explanation, Cover):
            return {"bases": [self.constraint(c) for c in explanation.bases],
                    "covers": [self.constraint(c) for c in explanation.covers]}
        out = {"source": self.constraint(explanation.constraint), "branches": self.branches(explanation.proof)}
        if isinstance(explanation, ImplicationMap):
            out["choices"] = [self.fact(fact) for fact in explanation.choices]
            out["links"] = [
                {"from": self.fact(link.source), "to": self.fact(link.target), "source": self.constraint(link.constraint)}
                for link in explanation.links
            ]
        return out

    def focus(self, attention: int) -> list[list[dict]]:
        """Where to look: each way of holding the step's atoms in the fewest rows,
        columns, boxes or digits (``Problem.focus_blocks``), smallest first."""
        options = sorted(self.game.problem.focus_blocks(attention), key=lambda blocks: sum(b.bit_count() for b in blocks))
        return [[dict(zip(("kind", "index", "digit"), self.game.region(block))) for block in blocks] for blocks in options]

    def move(self, move: Move, starts: int | None = None, looks: float | None = None) -> dict:
        """A move; inside a round, also the places it starts from and the looks
        to find it alone (``Round.step_looks``)."""
        e = move.effort
        return {
            "kind": KIND[type(move.explanation)],
            "idea": idea(move.explanation),
            "conclusions": [self.fact(fact) for fact in move.conclusions],
            "effort": {"burden": e.burden, "work": e.work, "span": e.span, "focus": e.focus, "clutter": e.clutter},
            "focus": self.focus(e.attention),
            **({} if starts is None else {"starts": starts, "looks": looks}),
            **self.explanation(move.explanation),
        }

    def round(self, found: Round) -> dict:
        """A round's effort and search (its open places, the places a step starts
        from and the looks to find one, D60), with its moves, each with its own."""
        return {"burden": found.burden, "places": found.places, "starts": found.starts, "looks": found.looks,
                "moves": [self.move(*shown) for shown in zip(found.moves, found.step_starts, found.step_looks)]}

    def atom(self, fact: dict) -> Fact:
        """A client's fact as the engine's, checked."""
        if not isinstance(fact, dict) or fact.keys() != {"cell", "digit", "value"}:
            raise ValueError("a fact is {cell, digit, value}")
        cell, digit, value = fact["cell"], fact["digit"], fact["value"]
        if type(cell) is not int or not 0 <= cell < 81 or type(digit) is not int or not 1 <= digit <= 9 or type(value) is not bool:
            raise ValueError("a fact needs a cell 0-80, a digit 1-9 and a true or false value")
        return Fact(self.game.atom_from_index(cell, digit), value)

    def board(self, state: State) -> dict:
        grid = self.game.board(state)
        return {
            "grid": list(grid),
            "candidates": [None if grid[cell] else list(self.game.candidates(state, cell)) for cell in range(81)],
        }

    def efforts(self, state: State, efforts: dict[int, int]) -> list:
        """A number per candidate, as ``board`` lists them: per cell, null when it
        is filled, else each candidate's number, or null where it has none."""
        grid = self.game.board(state)
        return [None if grid[cell] else [efforts.get(self.game.atom_from_index(cell, digit))
                                         for digit in self.game.candidates(state, cell)]
                for cell in range(81)]


def profile(value: DifficultyProfile) -> dict:
    return {"level": value.level, "search": value.search, "solved": value.solved, "limited": value.limited,
            "rounds": [list(item) for item in value.rounds]}


def rating(puzzle: str, rounds: Sequence[Round], value: DifficultyProfile) -> dict:
    """A puzzle's rating for the library: its canonical ``id`` (the min-lex
    form), the ``puzzle`` as given, its ``givens`` count, the profile's level,
    search, solved and limited, and its ``strip``: each round's effort, its
    looks and the ideas of its moves, in their order."""
    return {"id": minlex(puzzle), "puzzle": puzzle, "givens": sum(ch != "0" for ch in puzzle),
            "level": value.level, "search": value.search, "solved": value.solved, "limited": value.limited,
            "strip": [{"burden": found.burden, "looks": found.looks, "ideas": list(dict.fromkeys(idea(m.explanation) for m in found.moves))}
                      for found in rounds]}


def analyse(puzzle: str, *, max_effort: int | None = CEILING) -> Iterator[dict]:
    """The puzzle solved in rounds, as a stream of events, so that a client can
    show the board before the analysis is done.

    - ``{"type": "puzzle", "givens", "board", "ceiling"}`` first: the givens (81
      digits) and the starting board;
    - ``{"type": "verified", "solution", "unique"}``: the exact verifier's first
      solution (81 digits, or null) and whether it is the only one (null without
      a solution); never a premise of the rounds;
    - ``{"type": "round", "index", "burden", "places", "starts", "looks", "board",
      "moves"}`` per round (``Encoder.round``), the board being where it starts
      and the moves every move at its effort;
    - ``{"type": "end", "board", "profile", "rating", "levels"}`` last: the
      rating as ``rate`` gives it, and per round each candidate's level from
      there (``path.candidate_levels``, D74), listed as ``Encoder.efforts``
      lists them, null for a candidate no round decides.

    Raises ``ValueError`` for a malformed puzzle or ceiling.
    """
    game = SudokuGame(SudokuGame.parse(puzzle))
    walk = Rounds(game, max_effort=max_effort)
    encode = Encoder(game, walk.reasoner)
    yield {"type": "puzzle", "givens": [v for row in game.grid for v in row], "board": encode.board(walk.state),
           "ceiling": max_effort}
    solutions = exact_solutions(walk.reasoner, walk.state, limit=2)
    yield {"type": "verified", "solution": list(game.board(solutions[0])) if solutions else None,
           "unique": len(solutions) == 1 if solutions else None}
    made = []
    for index, found in enumerate(walk):
        made.append(found)
        yield {"type": "round", "index": index, "board": encode.board(found.state), **encode.round(found)}
    yield {"type": "end", "board": encode.board(walk.state), "profile": profile(walk.profile),
           "rating": rating(_text(game), made, walk.profile),
           "levels": [encode.efforts(found.state, each) for found, each in zip(made, candidate_levels(made, walk.state))]}


def _text(game: SudokuGame) -> str:
    return "".join(str(v) for row in game.grid for v in row)


def rate(puzzle: str) -> Iterator[dict]:
    """The puzzle's rating, at the rating's resolution: ``{"type": "rated",
    "rating"}`` (``rating``), once its rounds are worked out."""
    game = SudokuGame(SudokuGame.parse(puzzle))
    walk = Rounds(game)
    made = list(walk)
    yield {"type": "rated", "rating": rating(_text(game), made, walk.profile)}


def twin(puzzle: str, seed: int | None = None) -> Iterator[dict]:
    """A twin of the puzzle: ``{"type": "twin", "puzzle"}``, the puzzle under a
    random symmetry of the grid and relabelling of the digits, so the same puzzle
    to the rating (D32), which Compare shows. ``seed`` makes it repeatable."""
    game = SudokuGame(SudokuGame.parse(puzzle))
    yield {"type": "twin", "puzzle": scramble(_text(game), Random(seed))}


def ideas() -> Iterator[dict]:
    """The key ideas a made puzzle can be asked for, and at which levels (D73):
    ``{"type": "ideas", "levels": {idea: [level, ...]}}``. One option left is
    level 1 itself, so it is not a choice."""
    yield {"type": "ideas", "levels": {name: list(levels) for name, levels in LEVELS.items() if name != "single"}}


SEARCH = {"any": 0, "less": -1, "more": 1}  # what a made puzzle's search is asked to be (generate.climb)


def generate(level: int, seed: int | None = None, search: str = "any", idea: str = "any") -> Iterator[dict]:
    """A new puzzle at ``level`` (``generate.climb``), with ``search`` "any",
    "less" or "more", and ``idea`` "any" or the key idea (``ideas.IDEAS``, at the
    levels ``ideas.LEVELS`` gives), as a stream:

    - ``{"type": "tried", "tried"}`` for a puzzle tried and not kept, ``tried``
      counting every puzzle rated so far;
    - ``{"type": "climbed", "tried", "rating"}`` for each puzzle the climb
      stands on: rated, unique and solved, so a puzzle of its own level;
    - ``{"type": "made", "tried", "rating"}`` last: the puzzle it stands on, at
      the level.

    ``seed`` makes the stream repeatable. Raises ``ValueError`` for a level
    outside 1 to the ceiling, an unknown search, or an idea that cannot crack a
    puzzle of the level.
    """
    if seed is not None and type(seed) is not int:
        raise ValueError("a seed is a whole number")
    if search not in SEARCH:
        raise ValueError("search is any, less or more")
    if idea != "any" and idea not in IDEAS:
        raise ValueError(f"an idea is any or one of {', '.join(IDEAS)}")
    for step in generator.climb(level, Random(seed), search=SEARCH[search], idea=None if idea == "any" else idea):
        if isinstance(step, generator.Tried):
            yield {"type": "tried", "tried": step.tried}
            continue
        yield {"type": "made" if isinstance(step, generator.Made) else "climbed", "tried": step.tried,
               "rating": rating(step.puzzle, step.path.rounds, step.path.profile)}


class _Position:
    """A player's position: the givens plus their facts. ``shown`` holds every fact;
    ``state`` only those that agree with the verified solution, because a step is
    never reasoned from a mistake."""

    def __init__(self, puzzle: str, facts: list) -> None:
        if not isinstance(facts, list):
            raise ValueError("facts must be a list")
        self.game = SudokuGame(SudokuGame.parse(puzzle))
        self.reasoner = ExactOneReasoner(self.game.problem)
        self.encode = Encoder(self.game, self.reasoner)
        self.facts = [self.encode.atom(fact) for fact in facts]
        start = self.reasoner.initial()
        solutions = exact_solutions(self.reasoner, start, limit=2)
        self.unique = len(solutions) == 1 if solutions else None
        self.solution = solutions[0] if self.unique else None
        self.mistakes = [fact for fact in self.facts if self.solution and not self.agrees(fact)]
        self.shown = self.reasoner.apply_all(start, self.facts)
        self.state = self.reasoner.apply_all(start, (f for f in self.facts if f not in self.mistakes))

    def agrees(self, fact: Fact) -> bool:
        return bool(self.solution.true >> fact.atom & 1) == fact.value


def position(puzzle: str, facts: list | None = None, *, max_effort: int | None = CEILING) -> Iterator[dict]:
    """A player's position, for playing and hints (D51).

    - ``{"type": "position", "board", "mistakes", "solved", "unique"}``: the board
      with every fact applied, the facts that disagree with the verified solution
      (a check, never reasoning; empty unless the solution is unique), and
      whether the position is solved;
    - ``{"type": "searching", "at_least"}`` while the next round is searched
      for: no round costs less than ``at_least``;
    - then the next round from the player's correct facts: ``{"type": "round",
      "burden", "places", "starts", "looks", "moves"}``, or ``{"type": "stop",
      "limited"}`` when there is none.

    ``max_effort`` None works the round out whatever it costs: the app's way
    past the rating's ceiling, outside the rating (D58).
    """
    at = _Position(puzzle, facts or [])
    yield {"type": "position", "board": at.encode.board(at.shown), "mistakes": [at.encode.fact(f) for f in at.mistakes],
           "solved": not at.mistakes and at.reasoner.solved(at.shown), "unique": at.unique}
    for found in search_round(at.game, at.reasoner, at.state, max_effort=max_effort):
        if isinstance(found, Searching):
            yield {"type": "searching", "at_least": found.at_least}
        elif isinstance(found, Round):
            yield {"type": "round", **at.encode.round(found)}
        else:
            yield {"type": "stop", "limited": found.limited}


def ask(puzzle: str, facts: list | None = None, fact: dict | None = None, *, max_effort: int | None = CEILING) -> Iterator[dict]:
    """Why is this so, here? The cheapest step deciding ``fact`` at the player's
    position (from their correct facts): proving it, or placing what rules it
    out (D94); exact (CONCEPT.md, Appendix).

    - ``{"type": "searching", "at_least", "best"}`` while the search runs: no step
      below ``at_least`` proves it, and ``best`` (a move or null) does, so its
      effort is an upper bound;
    - ``{"type": "answer", "status", "move"}`` last. ``status`` is ``proven`` (the
      cheapest move), ``false`` (it disagrees with the verified solution: a
      check, not reasoning), ``decided`` (the position already shows it; for a
      removal, ``by`` lists the placements that rule it out, empty when the
      player removed it),
      ``unprovable`` (no single, cover or case split of any size proves it here)
      or ``limited`` (it costs more than ``max_effort``).
    """
    at = _Position(puzzle, facts or [])
    target = at.encode.atom(fact)
    if at.solution and not at.agrees(target):
        yield {"type": "answer", "status": "false", "move": None}
        return
    if at.state.shows(target):
        by = [] if fact["value"] else at.reasoner.excluders(at.state, target.atom)
        yield {"type": "answer", "status": "decided", "move": None,
               "by": [at.encode.fact(Fact(atom, True)) for atom in by]}
        return
    for item in cheapest(at.game, at.reasoner, at.state, target, max_effort=max_effort):
        if isinstance(item, Searching):
            yield {"type": "searching", "at_least": item.at_least,
                   "best": at.encode.move(item.best) if item.best else None}
        elif isinstance(item, Stop):
            yield {"type": "answer", "status": "limited", "move": None}
        elif item is None:
            yield {"type": "answer", "status": "unprovable", "move": None}
        else:
            yield {"type": "answer", "status": "proven", "move": at.encode.move(item)}


CALLS: dict[str, Callable[..., Iterator[dict]]] = {
    "analyse": analyse, "position": position, "ask": ask, "rate": rate, "generate": generate, "twin": twin,
    "ideas": ideas,
}


def run(name: str, args: dict) -> Iterator[tuple[str, str]]:
    """A call as its transports send it: ``("event", json)`` per event, then
    ``("done", "")``, or ``("invalid", message)`` for the caller's mistake (an
    unknown call, arguments that are not an object, or a ``ValueError`` or
    ``TypeError``) or ``("failed", message)`` for the engine's."""
    try:
        if name not in CALLS:
            raise ValueError(f"no call {name!r}")
        if not isinstance(args, dict):
            raise ValueError("the arguments must be a JSON object")
        for event in CALLS[name](**args):
            yield "event", json.dumps(event, separators=(",", ":"))
        yield "done", ""
    except (ValueError, TypeError) as exc:  # the caller's mistake
        yield "invalid", str(exc)
    except Exception as exc:  # noqa: BLE001 - reported to the client, never swallowed
        yield "failed", f"{type(exc).__name__}: {exc}"

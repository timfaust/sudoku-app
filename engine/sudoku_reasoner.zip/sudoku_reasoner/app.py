"""The desktop app: a local server for the browser UI and the engine service (D48).

``python -m sudoku_reasoner app`` serves the UI from ``web/`` and the service's
calls under ``/api/<name>``. It listens on the loopback interface only and
accepts only requests addressed to it by a local host name, so other sites in
the browser cannot reach it (no CORS, a JSON content type, and the Host check
against DNS rebinding).

Every call is a stream: its events go out as JSON lines as they are made. Each
call runs in its own process, so the server stays responsive, memory is returned
when it ends, and a client that closes the request cancels it.
"""
from __future__ import annotations

import argparse
import json
import multiprocessing
import select
import socket
import webbrowser
from collections.abc import Sequence
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from . import service

WEB = Path(__file__).resolve().parent / "web"
TYPES = {".html": "text/html", ".css": "text/css", ".js": "text/javascript", ".json": "application/json", ".woff2": "font/woff2",
         ".webmanifest": "application/manifest+json", ".png": "image/png", ".svg": "image/svg+xml"}
LOCAL_HOSTS = {"127.0.0.1", "localhost", "[::1]"}
SPAWN = multiprocessing.get_context("spawn")


def _run(name: str, args: dict, conn) -> None:
    """A call in its own process: send each of ``service.run``'s messages."""
    try:
        for message in service.run(name, args):
            conn.send(message)
    finally:
        conn.close()


class Handler(BaseHTTPRequestHandler):
    server: "AppServer"
    protocol_version = "HTTP/1.1"

    def log_message(self, format: str, *args) -> None:  # noqa: A002 - the base class's name
        if self.server.verbose:
            super().log_message(format, *args)

    def _local(self) -> bool:
        host = (self.headers.get("Host") or "").rsplit(":", 1)[0]
        return host in LOCAL_HOSTS

    def _send(self, status: HTTPStatus, body: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def _error(self, status: HTTPStatus, message: str) -> None:
        self._send(status, json.dumps({"error": message}).encode(), "application/json")

    def do_GET(self) -> None:  # noqa: N802 - the base class's name
        if not self._local():
            return self._error(HTTPStatus.FORBIDDEN, "only local requests are served")
        path = self.path.split("?", 1)[0].split("#", 1)[0]
        target = (WEB / (path.lstrip("/") or "index.html")).resolve()
        if WEB not in target.parents or not target.is_file() or target.suffix not in TYPES:
            return self._error(HTTPStatus.NOT_FOUND, "not found")
        content_type = TYPES[target.suffix]
        if content_type.startswith("text/"):
            content_type += "; charset=utf-8"
        self._send(HTTPStatus.OK, target.read_bytes(), content_type)

    def do_POST(self) -> None:  # noqa: N802 - the base class's name
        if not self._local():
            return self._error(HTTPStatus.FORBIDDEN, "only local requests are served")
        name = self.path.removeprefix("/api/")
        if not self.path.startswith("/api/") or name not in service.CALLS:
            return self._error(HTTPStatus.NOT_FOUND, f"no call {name!r}")
        if (self.headers.get("Content-Type") or "").split(";")[0].strip() != "application/json":
            return self._error(HTTPStatus.UNSUPPORTED_MEDIA_TYPE, "send JSON")
        try:
            args = json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)) or b"{}")
        except json.JSONDecodeError:
            return self._error(HTTPStatus.BAD_REQUEST, "the body is not JSON")
        if not isinstance(args, dict):
            return self._error(HTTPStatus.BAD_REQUEST, "the body must be a JSON object")
        self._stream(name, args)

    def _client_gone(self) -> bool:
        """Whether the client closed the connection (a cancelled call)."""
        readable, _, _ = select.select([self.connection], [], [], 0)
        if not readable:
            return False
        try:
            return self.connection.recv(1, socket.MSG_PEEK) == b""
        except OSError:
            return True

    def _stream(self, name: str, args: dict) -> None:
        receive, send = SPAWN.Pipe(duplex=False)
        job = SPAWN.Process(target=_run, args=(name, args, send), daemon=True)
        job.start()
        send.close()
        self.server.jobs.add(job)
        started = False
        try:
            while True:
                if not receive.poll(0.2):
                    if self._client_gone() or not job.is_alive() and not receive.poll(0):
                        break
                    continue
                kind, value = receive.recv()
                if not started and kind == "invalid":
                    return self._error(HTTPStatus.BAD_REQUEST, value)
                if not started:
                    self.send_response(HTTPStatus.OK)
                    self.send_header("Content-Type", "application/x-ndjson")
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("Transfer-Encoding", "chunked")
                    self.end_headers()
                    started = True
                if kind == "event":
                    self._chunk(value + "\n")
                elif kind != "done":
                    self._chunk(json.dumps({"type": "error", "message": value}) + "\n")
                if kind != "event":
                    break
            if started:
                self.wfile.write(b"0\r\n\r\n")
            elif not self._client_gone():
                self._error(HTTPStatus.INTERNAL_SERVER_ERROR, "the engine stopped without an answer")
        except (BrokenPipeError, ConnectionResetError, EOFError):
            pass  # the client went away: cancel below
        finally:
            receive.close()
            if job.is_alive():
                job.terminate()
            job.join()
            self.server.jobs.discard(job)
            self.close_connection = True

    def _chunk(self, text: str) -> None:
        data = text.encode()
        self.wfile.write(f"{len(data):x}\r\n".encode() + data + b"\r\n")
        self.wfile.flush()


class AppServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, port: int = 0, *, verbose: bool = False) -> None:
        self.verbose = verbose
        self.jobs: set = set()  # before binding, which closes the server if it fails
        super().__init__(("127.0.0.1", port), Handler)

    @property
    def url(self) -> str:
        return f"http://localhost:{self.server_address[1]}/"

    def server_close(self) -> None:
        for job in list(self.jobs):
            job.terminate()
        super().server_close()


def main(argv: Sequence[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m sudoku_reasoner app", description="Run the Sudoku app locally")
    p.add_argument("--port", type=int, default=8642, help="local port (default %(default)s; 0 picks a free one)")
    p.add_argument("--puzzle", help="open this puzzle (81 digits, 0 or . for empty)")
    p.add_argument("--no-browser", action="store_true", help="do not open the browser")
    p.add_argument("--verbose", action="store_true", help="log every request")
    args = p.parse_args(argv)
    with AppServer(args.port, verbose=args.verbose) as server:
        start = server.url + (f"#analyse/{''.join(args.puzzle.split()).replace('.', '0')}" if args.puzzle else "")
        print(f"Sudoku app: {start} (Ctrl+C stops it)")
        if not args.no_browser:
            webbrowser.open(start)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
    return 0

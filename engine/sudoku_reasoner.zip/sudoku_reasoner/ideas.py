"""The four ideas a step teaches (D61): one option left, counting, assume and
fail, whatever you choose. Outside the rating's hash: the rating never names an
idea; the service words them and the generator steers by them (D73)."""
from __future__ import annotations

from collections.abc import Iterable

from .sudoku.explain import Cover, Explanation, Single
from .sudoku.path import CEILING, Round

IDEAS = ("single", "count", "fail", "cases")

# The levels at which a made puzzle can be asked to be cracked by each idea.
# The effort model bounds them (CONCEPT.md §3): only a single costs 1, every
# other step at least 2, and a cover of k bases costs k + 1 with k ≤ 4 enough
# for every cover in Sudoku, so counting cracks levels 2 to 5. Within those
# bounds, counting at 5 and assume and fail below 4 were never made in the
# measurement and are rare or absent in rated puzzles (RESULTS.md, Generator),
# so they are not offered.
LEVELS = {"single": range(1, 2), "count": range(2, 5), "fail": range(4, CEILING + 1), "cases": range(2, CEILING + 1)}


def idea(explanation: Explanation) -> str:
    """The idea an explanation teaches: a refutation is the only case split
    without a constraint (D42)."""
    if isinstance(explanation, Single):
        return "single"
    if isinstance(explanation, Cover):
        return "count"
    return "fail" if explanation.constraint is None else "cases"


def key_ideas(rounds: Iterable[Round], level: int) -> set[str]:
    """The ideas of every step at ``level``: what cracks a puzzle of that level."""
    return {idea(move.explanation) for found in rounds if found.burden == level for move in found.moves}

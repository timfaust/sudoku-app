"""Moves: the catalogue's conclusions grouped by explanation (D5, D57).

Each conclusion is charged by its own proofs, focus on that conclusion included
(D41). A move is one explanation with every conclusion it explains at the same
effort: a cover with its eliminations, or a case split with each conclusion
whose proof reads as the same branches at that effort. Nothing the catalogue
did not prove is added (CONCEPT.md §4).
"""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass

from ..core.model import Fact, State
from ..core.reasoning import Catalogue
from .effort import Effort
from .explain import KIND_ORDER, CaseSplit, Explanation, ImplicationMap, explain
from .game import SudokuGame


@dataclass(frozen=True, slots=True)
class Move:
    explanation: Explanation
    conclusions: tuple[Fact, ...]  # placements first

    @property
    def effort(self) -> Effort:
        return self.explanation.effort


def move_key(move: Move) -> tuple:
    """Cheapest first; among equals (presentation only): placements, more
    conclusions, simpler kinds, the effort's tie-breaks, then the facts."""
    return (
        move.effort.burden,
        not move.conclusions[0].value,
        -len(move.conclusions),
        KIND_ORDER[type(move.explanation)],
        move.effort.key,
        tuple((fact.atom, not fact.value) for fact in move.conclusions),
    )


def _identity(explanation: Explanation):
    """A case split and its implication map are two views of one explanation."""
    if isinstance(explanation, (CaseSplit, ImplicationMap)):
        return "case", explanation.constraint, explanation.branches
    return explanation


def readings(game: SudokuGame, state: State, catalogue: Catalogue) -> tuple[Move, ...]:
    """Every explanation of the catalogue as a move, best first."""
    groups: dict[tuple, list] = {}  # (identity, effort) -> [its cheapest reading, its conclusions]
    for fact in sorted(catalogue, key=lambda f: (not f.value, f.atom)):
        for proof in catalogue[fact]:
            explanation = explain(game, state, proof)
            group = groups.setdefault((_identity(explanation), explanation.effort.burden), [explanation, []])
            if explanation.effort.key < group[0].effort.key:
                group[0] = explanation
            if fact not in group[1]:
                group[1].append(fact)
    return tuple(sorted((Move(explanation, tuple(facts)) for explanation, facts in groups.values()), key=move_key))


def undominated(found: Sequence[Move]) -> tuple[Move, ...]:
    """The moves no other proves at least the conclusions of at no greater
    effort; ``found`` best first."""
    kept: list[tuple[Move, set[Fact]]] = []
    for move in found:
        proven = set(move.conclusions)
        # Sorted by effort, so every move kept so far costs no more.
        if not any(proven <= other for _, other in kept):
            kept.append((move, proven))
    return tuple(move for move, _ in kept)


def moves(game: SudokuGame, state: State, catalogue: Catalogue) -> tuple[Move, ...]:
    """Every undominated move of the catalogue, best first."""
    return undominated(readings(game, state, catalogue))

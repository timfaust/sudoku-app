"""Min-lex canonical form of a Sudoku puzzle: its id in the library and the harness.

Two puzzles are equivalent when one maps to the other by a validity-preserving
symmetry: transposition, permuting bands, rows within a band, stacks, columns
within a stack, and relabelling digits. The canonical form is the
lexicographically smallest 81-character string (``0`` for blanks) over all of
them, with digits relabelled in order of first appearance.

The search fixes one output row at a time and keeps every partial symmetry that
ties for the smallest prefix, so it is exact.
"""
from __future__ import annotations

import random
from itertools import permutations, product

_COLUMN_ORDERS = tuple(
    tuple(3 * stack + offset for stack in stacks for offset in inner[stack])
    for stacks in permutations(range(3))
    for inner in product(permutations(range(3)), repeat=3)
)


def _parse(puzzle: str) -> tuple[int, ...]:
    chars = [ch for ch in puzzle if not ch.isspace()]
    if len(chars) != 81 or any(ch not in "0123456789." for ch in chars):
        raise ValueError("puzzle must be exactly 81 digits/dots")
    return tuple(0 if ch in "0." else int(ch) for ch in chars)


def _next_rows(used: tuple[int, ...]) -> tuple[int, ...]:
    if len(used) % 3:
        band = used[-1] // 3
        return tuple(r for r in range(3 * band, 3 * band + 3) if r not in used)
    bands = {r // 3 for r in used}
    return tuple(r for r in range(9) if r // 3 not in bands)


def minlex(puzzle: str) -> str:
    grid = _parse(puzzle)
    transposed = tuple(grid[c * 9 + r] for r in range(9) for c in range(9))
    # A partial symmetry: (grid, rows placed so far, column order, digit labels).
    states = [(g, (), cols, (0,) * 10) for g in (grid, transposed) for cols in _COLUMN_ORDERS]
    out: list[int] = []
    for _ in range(9):
        best: tuple[int, ...] | None = None
        survivors = []
        for g, used, cols, labels in states:
            for row in _next_rows(used):
                labels_out = list(labels)
                next_label = max(labels_out) + 1
                text = []
                for col in cols:
                    value = g[row * 9 + col]
                    if value and not labels_out[value]:
                        labels_out[value] = next_label
                        next_label += 1
                    text.append(labels_out[value] if value else 0)
                key = tuple(text)
                if best is None or key < best:
                    best, survivors = key, []
                if key == best:
                    survivors.append((g, used + (row,), cols, tuple(labels_out)))
        out.extend(best)
        states = survivors
    return "".join(map(str, out))


def scramble(puzzle: str, rng: random.Random) -> str:
    """Apply a random validity-preserving symmetry and digit relabelling."""
    grid = _parse(puzzle)
    if rng.random() < 0.5:
        grid = tuple(grid[c * 9 + r] for r in range(9) for c in range(9))
    rows = [3 * band + offset for band in rng.sample(range(3), 3) for offset in rng.sample(range(3), 3)]
    cols = [3 * stack + offset for stack in rng.sample(range(3), 3) for offset in rng.sample(range(3), 3)]
    relabel = (0, *rng.sample(range(1, 10), 9))
    return "".join(str(relabel[grid[r * 9 + c]]) for r in rows for c in cols)

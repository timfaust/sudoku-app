"""Explanations: how a human reads one of the core's proofs (D5, CONCEPT.md §3).

Each is a frozen dataclass whose compared fields are its structure, so equal
structures found from different conclusions are one explanation; each carries
its effort. A single, a case split and a cover present a proof as it is; an
implication map is a view of a case split (``implication_map``).
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..core.model import Branch, Fact, Proof, Relation, State
from .effort import Effort, cover_effort, graph_effort, proof_effort
from .game import SudokuGame

Steps = tuple[tuple[int, bool, tuple[Fact, ...]], ...]  # per branch: assumption, contradiction, steps


@dataclass(frozen=True, slots=True)
class Single:
    """One option left in a constraint."""

    fact: Fact
    constraint: int
    effort: Effort = field(compare=False)


@dataclass(frozen=True, slots=True)
class Cover:
    """k base constraints whose options lie in k cover constraints of another
    family: naked or hidden subsets, intersections and fish."""

    bases: tuple[int, ...]
    covers: tuple[int, ...]
    effort: Effort = field(compare=False)


@dataclass(frozen=True, slots=True)
class CaseSplit:
    """Each option of one exhaustive choice, followed by its forced singles. A
    refutation (no constraint) has one branch, Z, which fails."""

    constraint: int | None
    branches: Steps
    proof: Proof = field(compare=False)
    effort: Effort = field(compare=False)


@dataclass(frozen=True, slots=True)
class ImplicationLink:
    """One causal edge shared by the branches of a case proof."""

    source: Fact
    target: Fact
    constraint: int


@dataclass(frozen=True, slots=True)
class ImplicationMap:
    """The branches of a case split merged into one map of shared consequences."""

    constraint: int
    branches: Steps
    choices: tuple[Fact, ...] = field(compare=False)
    links: tuple[ImplicationLink, ...] = field(compare=False)
    proof: Proof = field(compare=False)
    effort: Effort = field(compare=False)


Explanation = Single | Cover | CaseSplit | ImplicationMap
KIND_ORDER = {Cover: 0, Single: 1, ImplicationMap: 2, CaseSplit: 3}


def cover(game: SudokuGame, state: State, relation: Relation) -> Cover:
    """The relation with its effort from the option counts of its bases (D34)."""
    options, live = [], 0
    for cid in relation.bases:
        mine = state.possible & sum(1 << atom for atom in game.problem.constraints[cid].atoms)
        options.append(mine.bit_count())
        live |= mine
    return Cover(relation.bases, relation.covers, cover_effort(tuple(options), live))


def _branch_signature(branch: Branch) -> tuple[int, bool, tuple[Fact, ...]]:
    return branch.assumption, branch.contradiction, tuple(step.facts[0] for step in branch.steps)


def implication_map(
    game: SudokuGame,
    proof: Proof,
) -> tuple[tuple[Fact, ...], tuple[ImplicationLink, ...]] | None:
    """The case proof's branches merged into choices and links, or None.

    It searches for nothing and proves nothing new. It exists only when every
    conclusion has explicit support in every branch, so a proof with a failing
    branch keeps the case-by-case reading.
    """
    if proof.is_direct or any(branch.contradiction for branch in proof.branches):
        return None
    links: set[ImplicationLink] = set()
    choices = tuple(Fact(branch.assumption, True) for branch in proof.branches)

    def sources(placed: dict[int, int], atom: int, target: int = -1) -> list[int]:
        """Every shallowest placement other than ``target`` that eliminates ``atom``."""
        found = [s for s in placed if s != target and game.shared_constraint(s, atom) is not None]
        least = min((placed[s] for s in found), default=None)
        return [s for s in found if placed[s] == least]

    for branch in proof.branches:
        # Each placement's depth is the least fixpoint of one more than its
        # deepest needed elimination, each through its shallowest source, in
        # the constraint that forces it soonest: independent of step order and ids.
        targets = {fact.atom for step in branch.steps for fact in step.facts if fact.value}
        needed = {
            target: {
                cid: [a for a in game.problem.constraints[cid].atoms if a != target and proof.start.possible >> a & 1]
                for cid in game.problem.memberships[target]
            }
            for target in targets
        }

        def forcing(placed: dict[int, int], target: int) -> dict[int, int]:
            """The depth each constraint would give the target, where it forces it."""
            return {
                cid: 1 + max((placed[sources(placed, a, target)[0]] for a in atoms), default=0)
                for cid, atoms in needed[target].items() if all(sources(placed, a, target) for a in atoms)
            }

        placed = {branch.assumption: 0}
        changed = True
        while changed:
            changed = False
            for target in targets:
                depth = min(forcing(placed, target).values(), default=None)
                if depth is not None and depth < placed.get(target, depth + 1):
                    placed[target] = depth
                    changed = True
        if placed.keys() != {branch.assumption, *targets}:
            return None
        for target in targets:
            for cid, depth in forcing(placed, target).items():
                if depth == placed[target]:
                    for atom in needed[target][cid]:
                        for source in sources(placed, atom, target):
                            links.add(ImplicationLink(Fact(source, True), Fact(target, True), cid))

        for conclusion in proof.facts:
            if conclusion.value:
                if conclusion.atom not in placed:
                    return None
                continue
            found = sources(placed, conclusion.atom)
            if not found:
                return None
            for source in found:
                links.add(ImplicationLink(Fact(source, True), conclusion, game.shared_constraint(source, conclusion.atom)))

    if not links:
        return None
    return choices, tuple(sorted(
        links,
        key=lambda link: (link.source.atom, not link.source.value, link.target.atom, not link.target.value, link.constraint),
    ))


def case_explanation(game: SudokuGame, proof: Proof) -> CaseSplit | ImplicationMap:
    """The case split as proven, or its implication map when that costs no more."""
    branches = tuple(_branch_signature(branch) for branch in proof.branches)
    effort = proof_effort(game, proof)
    graph = implication_map(game, proof)
    if graph is not None:
        choices, links = graph
        map_effort = graph_effort(game, choices, links)
        if map_effort.key <= effort.key:
            return ImplicationMap(proof.constraint, branches, choices, links, proof, map_effort)
    return CaseSplit(proof.constraint, branches, proof, effort)


def explain(game: SudokuGame, state: State, proof: Proof | Relation) -> Explanation:
    """The explanation of one proof in the catalogue of ``state``."""
    if isinstance(proof, Relation):
        return cover(game, state, proof)
    if proof.is_direct:
        (fact,) = proof.facts
        return Single(fact, proof.constraint, proof_effort(game, proof))
    return case_explanation(game, proof)

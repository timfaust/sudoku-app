"""Effort: what following one explanation costs (CONCEPT.md §3).

Every explanation is charged ``burden = work + span + focus - 2``; only how work,
span and focus are read differs between a raw case proof, its implication map
and a cover. On a state without singles no reading of a case proof costs less
than the atoms it holds (least burden), which makes the search by need exact.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..core.model import Fact, Proof
from .game import SudokuGame

SINGLE = 1  # a single's effort; every other explanation follows at least two facts


@dataclass(frozen=True, slots=True)
class Effort:
    """``burden`` (effort in the UI) from ``work``, ``span`` and ``focus``;
    ``clutter`` only orders equals, and ``attention`` holds the atoms whose
    coherence is the focus: where to look."""

    burden: int
    work: int
    span: int
    focus: int
    clutter: int = 0
    attention: int = field(default=0, compare=False)

    @property
    def key(self) -> tuple[int, int, int, int, int]:
        return self.burden, self.clutter, self.span, self.work, self.focus


def effort(work: int, span: int, focus: int, clutter: int = 0, attention: int = 0) -> Effort:
    return Effort(work + span + focus - 2, work, span, focus, clutter, attention)


def mask(atoms: set[int]) -> int:
    return sum(1 << atom for atom in atoms)


def focus(game: SudokuGame, atoms: set[int]) -> int:
    """The fewest digits, rows, columns or boxes holding the atoms: the core's coherence."""
    return game.problem.coherence(mask(atoms))


def _followed(proof: Proof) -> set[int]:
    """What a reader follows: the conclusion (D41), and a case split's
    assumptions and placements."""
    atoms = {fact.atom for fact in proof.facts}
    for branch in proof.branches:
        atoms.add(branch.assumption)
        for step in branch.steps:
            atoms.update(fact.atom for fact in step.facts if fact.value)
    return atoms


def proof_effort(game: SudokuGame, proof: Proof) -> Effort:
    """A single or a raw case proof: its work and span, plus focus."""
    atoms = _followed(proof)
    return effort(proof.size.work, proof.size.span, focus(game, atoms), attention=mask(atoms))


def graph_effort(game: SudokuGame, choices: tuple[Fact, ...], links: tuple) -> Effort:
    """An implication map (``links`` of ``ImplicationLink``): its positive atoms
    are the work, its depth the span, its atoms and link targets the focus."""
    positive_atoms = {fact.atom for fact in choices} | {
        fact.atom for link in links for fact in (link.source, link.target) if fact.value
    }
    focus_atoms = positive_atoms | {link.target.atom for link in links}
    depth = {fact: 0 for fact in choices}
    for _ in range(len(links) + 1):
        changed = False
        for link in links:
            candidate = depth.get(link.source, 0) + 1
            if candidate > depth.get(link.target, 0):
                depth[link.target] = candidate
                changed = True
        if not changed:
            break
    work = len(positive_atoms)
    span = max(depth.values(), default=1)
    return effort(work, span, focus(game, focus_atoms), max(0, len(links) - len(positive_atoms)), mask(focus_atoms))


def cover_effort(options: tuple[int, ...], attention: int = 0) -> Effort:
    """A cover of k bases (D34): work k (one truth per base), span 2 (the truths
    fill the covers, which exclude their other options), focus 1 (one house or
    digit), so effort k + 1. Clutter counts base options beyond two per base."""
    return effort(len(options), 2, 1, sum(max(0, n - 2) for n in options), attention)

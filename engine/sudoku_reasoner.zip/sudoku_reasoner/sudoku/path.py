"""The human path: the puzzle solved in rounds (D30) until solved or stalled.

A round applies, at once, the conclusions of every move at the state's lowest
effort; the level is the largest round effort, and search adds up the looks to
find each round's first step (CONCEPT.md §5). Each round is
searched by need, so no proof limit enters it (D39, §6). The effort ceiling is the
rating's resolution (D58): it stops the path before a harder round and says so,
and changes no round below it.
"""
from __future__ import annotations

from collections import Counter
from collections.abc import Iterator, Sequence
from dataclasses import dataclass
from itertools import accumulate, count

from ..core.model import Fact, State, bits
from ..core.reasoning import ExactOneReasoner
from .effort import SINGLE
from .explain import Cover, Explanation, Single
from .game import SudokuGame
from .moves import Move, moves, readings, undominated

CEILING = 10  # the rating's resolution (D58): levels are exact up to it; None searches on

@dataclass(frozen=True, slots=True)
class DifficultyProfile:
    """A puzzle's difficulty (D31, D60): ``level``, the largest round effort, and
    ``search``, the rounds' looks added up (a stalled puzzle keeps those of the
    rounds it made); ``solved``; ``limited``, why it stalled (D40: true at the
    effort ceiling, false beyond the proof language); ``rounds`` at each effort."""

    solved: bool
    limited: bool
    level: int
    search: float
    rounds: tuple[tuple[int, int], ...]  # (effort, rounds at that effort), by effort

    @classmethod
    def of(cls, rounds: Sequence[tuple[int, float]], solved: bool, limited: bool) -> DifficultyProfile:
        """From (effort, looks) of each round, in order."""
        counts = Counter(effort for effort, _ in rounds)
        return cls(solved, limited, max(counts, default=0), sum(looks for _, looks in rounds), tuple(sorted(counts.items())))


@dataclass(frozen=True, slots=True)
class Round:
    state: State  # where the round starts
    moves: tuple[Move, ...]  # every move at the round's effort, in presentation order
    places: int  # the open constraints: where a reader can look (D60)
    starts: int  # the places a step at the round's effort starts from
    step_starts: tuple[int, ...]  # per move: the places a reading of one of its conclusions starts from

    @property
    def burden(self) -> int:
        return self.moves[0].effort.burden

    @property
    def looks(self) -> float:
        """The places read, in no particular order, until the first start: in
        expectation (places + 1) / (starts + 1) (CONCEPT.md §5)."""
        return (self.places + 1) / (self.starts + 1)

    @property
    def step_looks(self) -> tuple[float, ...]:
        """Per move, the looks to find it alone, in no order: how hidden it is.
        Shown, never added up: the round's search is its first find (§5)."""
        return tuple((self.places + 1) / (starts + 1) for starts in self.step_starts)

    @property
    def conclusions(self) -> tuple[Fact, ...]:
        return tuple(dict.fromkeys(fact for move in self.moves for fact in move.conclusions))

    @property
    def placements(self) -> int:
        return sum(fact.value for fact in self.conclusions)


def _starts(reasoner: ExactOneReasoner, state: State, explanation: Explanation) -> tuple[int, ...]:
    """The places a reader can find the explanation from (D60): a cover's bases;
    a refutation's constraints holding Z; else every open constraint left with
    exactly its choice's options (a single's one, a split's several)."""
    if isinstance(explanation, Cover):
        return explanation.bases
    if isinstance(explanation, Single):
        return reasoner.with_options(state, 1 << explanation.fact.atom)
    if explanation.constraint is None:
        return reasoner.memberships[explanation.branches[0][0]]
    return reasoner.with_options(state, state.possible & reasoner.masks[explanation.constraint])


def _round(reasoner: ExactOneReasoner, state: State, found: Sequence[Move]) -> Round:
    """The round of ``found``, every reading at the state's lowest effort, best
    first: its moves, where any of them starts, and where each move does, from
    every reading that concludes one of its conclusions."""
    reach = [(set(move.conclusions), set(_starts(reasoner, state, move.explanation))) for move in found]
    moves = undominated(found)
    step_starts = tuple(len(set().union(*(at for shown, at in reach if shown & set(move.conclusions)))) for move in moves)
    starts = set().union(*(at for _, at in reach))
    return Round(state, moves, len(reasoner.open_constraints(state)), len(starts), step_starts)


@dataclass(frozen=True, slots=True)
class HumanPath:
    rounds: tuple[Round, ...]
    end: State  # solved, or where the path stopped
    profile: DifficultyProfile


@dataclass(frozen=True, slots=True)
class Stop:
    """Why there is no next round: nothing concludes anything (solved,
    contradictory, or beyond the proof language), or ``limited``, the next round
    would cost more than the effort ceiling."""

    limited: bool


def _check_ceiling(max_effort: int | None) -> None:
    if max_effort is not None and max_effort <= SINGLE:
        raise ValueError("max_effort must exceed a single's effort")


@dataclass(frozen=True, slots=True)
class Searching:
    """A search at work: no move below ``at_least`` proves the fact, or makes a
    round, and ``best`` is the cheapest found so far (an upper bound; ``cheapest``
    only)."""

    at_least: int
    best: Move | None


def search_round(
    game: SudokuGame, reasoner: ExactOneReasoner, state: State, *, max_effort: int | None = CEILING,
) -> Iterator[Searching | Round | Stop]:
    """``next_round`` as a stream: a ``Searching`` per need passed, then the round
    or why there is none."""
    _check_ceiling(max_effort)
    # Nothing costs as little as a single, so a state with singles has a round of them.
    if singles := reasoner.singles(state):
        yield _round(reasoner, state, readings(game, state, singles))
        return
    # By need (§6): without singles, every move of effort up to ``need`` comes
    # from a proof holding at most ``need`` atoms.
    for need in count(SINGLE + 1):
        if max_effort is not None and need > max_effort:
            yield Stop(limited=True)
            return
        found = readings(game, state, reasoner.catalogue(state, max_held=need))
        if found and found[0].effort.burden <= need:
            effort = found[0].effort.burden  # readings come cheapest first
            yield _round(reasoner, state, tuple(move for move in found if move.effort.burden == effort))
            return
        # Covers are in every catalogue, so only a case split could still prove
        # something; branch closures decide whether one does.
        if not found and need == SINGLE + 1 and not any(reasoner.unbounded(state)):
            yield Stop(limited=False)
            return
        yield Searching(need + 1, None)


def next_round(
    game: SudokuGame, reasoner: ExactOneReasoner, state: State, *, max_effort: int | None = CEILING,
) -> Round | Stop:
    """The round at ``state``: every move at its lowest effort, or why there is none."""
    return next(found for found in search_round(game, reasoner, state, max_effort=max_effort)
                if not isinstance(found, Searching))


def cheapest(
    game: SudokuGame, reasoner: ExactOneReasoner, state: State, fact: Fact, *, max_effort: int | None = CEILING,
) -> Iterator[Searching | Move | Stop | None]:
    """The cheapest move deciding ``fact`` at ``state``: concluding it, or
    placing what rules it out (D94). As a stream: a ``Searching`` per need, then
    the answer: the move; None when nothing proves it (decided already, or no
    proof of any size); or ``Stop(limited=True)`` above ``max_effort``. Exact at
    any state, singles or not: no reading of a case proof costs less than the
    atoms it holds (CONCEPT.md, Appendix)."""
    if state.shows(fact):
        yield None
        return

    def decides(conclusions) -> bool:
        return fact in conclusions or reasoner.apply_all(state, conclusions).shows(fact)

    singles = reasoner.singles(state)
    deciding = {single: proofs for single, proofs in singles.items() if decides((single,))}
    if deciding:
        yield moves(game, state, deciding)[0]
        return
    placed, eliminated = reasoner.unbounded(state)
    if fact not in reasoner.eliminations(state) and not (placed if fact.value else eliminated) >> fact.atom & 1:
        yield None
        return
    best = None
    for need in count(SINGLE + 1):
        if max_effort is not None and need > max_effort:
            yield Stop(limited=True)
            return
        found = [move for move in moves(game, state, reasoner.catalogue(state, max_held=need)) if decides(move.conclusions)]
        if found and (best is None or found[0].effort.burden <= best.effort.burden):
            best = found[0]
        if best is not None and best.effort.burden <= need:
            yield best
            return
        yield Searching(need + 1, best)


def candidate_levels(rounds: Sequence[Round], end: State) -> tuple[dict[int, int], ...]:
    """Per round, each live candidate's level from there (D74): the largest
    effort of the rounds from that one to the round that places or removes it.
    Under effort monotonicity (P11) it is the least peak effort of any way to
    decide the candidate from there, as the level is the puzzle's (CONCEPT.md
    §5). A candidate no round decides (a stall, or the ceiling) has none."""
    states = [found.state for found in rounds] + [end]
    decided: dict[int, int] = {}
    for index, (before, after) in enumerate(zip(states, states[1:])):
        for atom in bits(before.possible & ~before.true & ~(after.possible & ~after.true)):
            decided[atom] = index
    out = []
    for start, found in enumerate(rounds):
        peaks = list(accumulate((r.burden for r in rounds[start:]), max))
        live = found.state.possible & ~found.state.true
        out.append({atom: peaks[decided[atom] - start] for atom in bits(live) if atom in decided})
    return tuple(out)


class Rounds:
    """The rounds from the givens, one at a time, until the puzzle is solved or
    no proof concludes anything. After iterating, ``state`` is where they
    stopped and ``profile`` sums them up."""

    def __init__(self, game: SudokuGame, *, max_effort: int | None = CEILING) -> None:
        _check_ceiling(max_effort)
        self.game = game
        self.max_effort = max_effort
        self.reasoner = ExactOneReasoner(game.problem)
        self.state = self.reasoner.initial()
        self.limited = False
        self._made: list[tuple[int, float]] = []

    def __iter__(self) -> Iterator[Round]:
        while isinstance(found := next_round(self.game, self.reasoner, self.state, max_effort=self.max_effort), Round):
            yield found
            self._made.append((found.burden, found.looks))
            self.state = self.reasoner.apply_all(self.state, found.conclusions)
        self.limited = found.limited

    @property
    def profile(self) -> DifficultyProfile:
        return DifficultyProfile.of(self._made, self.reasoner.solved(self.state), self.limited)


def human_path(game: SudokuGame, *, max_effort: int | None = CEILING) -> HumanPath:
    """The rounds until the puzzle is solved, no proof concludes anything, or
    the next round would cost more than ``max_effort``."""
    walk = Rounds(game, max_effort=max_effort)
    rounds = tuple(walk)
    return HumanPath(rounds, walk.state, walk.profile)

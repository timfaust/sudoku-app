"""Standard 9×9 Sudoku as an exact-one problem."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from ..core.model import Atom, Constraint, Problem, State, bits

Grid = tuple[tuple[int, ...], ...]
Board = bytes
DIGITS = range(1, 10)
CELL_FAMILY, ROW_FAMILY, COLUMN_FAMILY, BOX_FAMILY = range(4)  # constraint families


BOX_CELLS = tuple(
    tuple(row * 9 + col for row in range(top, top + 3) for col in range(left, left + 3))
    for top in (0, 3, 6) for left in (0, 3, 6)
)


@dataclass(frozen=True, slots=True)
class ConstraintMeta:
    kind: str
    index: int
    digit: int | None = None


class SudokuGame:
    atom_count = 729

    def __init__(self, grid: Grid) -> None:
        self.grid = self.validate_grid(grid)
        constraints: list[Constraint] = []
        meta: list[ConstraintMeta] = []

        for cell in range(81):
            constraints.append(Constraint(tuple(self.atom_from_index(cell, d) for d in DIGITS), CELL_FAMILY))
            meta.append(ConstraintMeta("cell", cell))
        for row in range(9):
            for digit in DIGITS:
                constraints.append(Constraint(tuple(self.atom(row, col, digit) for col in range(9)), ROW_FAMILY))
                meta.append(ConstraintMeta("row", row, digit))
        for col in range(9):
            for digit in DIGITS:
                constraints.append(Constraint(tuple(self.atom(row, col, digit) for row in range(9)), COLUMN_FAMILY))
                meta.append(ConstraintMeta("column", col, digit))
        for box, cells in enumerate(BOX_CELLS):
            for digit in DIGITS:
                constraints.append(Constraint(tuple(self.atom_from_index(cell, digit) for cell in cells), BOX_FAMILY))
                meta.append(ConstraintMeta("box", box, digit))

        givens = tuple(
            self.atom(r, c, value)
            for r, row in enumerate(self.grid)
            for c, value in enumerate(row)
            if value
        )
        self.problem = Problem(self.atom_count, tuple(constraints), givens)
        self.constraint_meta = tuple(meta)

    def shared_constraint(self, first: Atom, second: Atom) -> int | None:
        """The lowest constraint holding two distinct atoms, or None.

        Two candidates conflict exactly when one exists. A same-digit pair in a
        line and a box gets the line, whose id is lower.
        """
        if first == second:
            return None
        theirs = self.problem.memberships[second]
        return next((cid for cid in self.problem.memberships[first] if cid in theirs), None)

    @staticmethod
    def region(block: int) -> tuple[str, int | None, int | None]:
        """A block of a family-pair partition (``Problem.focus_blocks``) as a Sudoku
        region (kind, index, digit): a row, column or box (no digit), a digit (no
        index), or one digit in a band or stack of boxes."""
        cells = {atom // 9 for atom in bits(block)}
        digits = {atom % 9 + 1 for atom in bits(block)}
        rows = {cell // 9 for cell in cells}
        cols = {cell % 9 for cell in cells}
        if len(digits) == 1:
            (digit,) = digits
            if len(cells) == 81:
                return "digit", None, digit
            return ("band", min(rows) // 3, digit) if len(rows) == 3 else ("stack", min(cols) // 3, digit)
        if len(rows) == 1:
            return "row", min(rows), None
        if len(cols) == 1:
            return "column", min(cols), None
        return "box", min(rows) // 3 * 3 + min(cols) // 3, None

    @staticmethod
    def atom(row: int, col: int, digit: int) -> Atom:
        return (row * 9 + col) * 9 + digit - 1

    @staticmethod
    def atom_from_index(index: int, digit: int) -> Atom:
        return index * 9 + digit - 1

    @staticmethod
    def decode(atom: Atom) -> tuple[int, int, int]:
        cell, digit = divmod(atom, 9)
        return cell // 9, cell % 9, digit + 1

    @staticmethod
    def validate_grid(grid: Grid) -> Grid:
        if len(grid) != 9 or any(len(row) != 9 for row in grid):
            raise ValueError("Sudoku grid must be exactly 9x9")
        if any(type(v) is not int or not 0 <= v <= 9 for row in grid for v in row):
            raise ValueError("Sudoku values must be integers from 0 to 9")

        def duplicate(values: Iterable[int]) -> bool:
            values = [v for v in values if v]
            return len(values) != len(set(values))

        for r, row in enumerate(grid):
            if duplicate(row):
                raise ValueError(f"duplicate fixed digit in row {r + 1}")
        for c in range(9):
            if duplicate(grid[r][c] for r in range(9)):
                raise ValueError(f"duplicate fixed digit in column {c + 1}")
        for b, cells in enumerate(BOX_CELLS):
            if duplicate(grid[i // 9][i % 9] for i in cells):
                raise ValueError(f"duplicate fixed digit in box {b + 1}")
        return tuple(tuple(row) for row in grid)

    @classmethod
    def parse(cls, text: str) -> Grid:
        chars = [ch for ch in text if not ch.isspace()]
        if len(chars) != 81 or any(ch not in "0123456789." for ch in chars):
            raise ValueError("puzzle must be exactly 81 digits/dots (whitespace is allowed)")
        values = [0 if ch in "0." else int(ch) for ch in chars]
        grid = tuple(tuple(values[r * 9:(r + 1) * 9]) for r in range(9))
        return cls.validate_grid(grid)

    def board(self, state: State) -> Board:
        board = [0] * 81
        for atom in bits(state.true):
            r, c, d = self.decode(atom)
            board[r * 9 + c] = d
        return bytes(board)

    def candidates(self, state: State, cell: int) -> tuple[int, ...]:
        base = cell * 9
        return tuple(d for d in DIGITS if state.possible & (1 << (base + d - 1)))

    def format(self, state: State) -> str:
        return format_board(self.board(state))


def format_board(board: Board) -> str:
    lines = []
    for r in range(9):
        if r and r % 3 == 0:
            lines.append("------+-------+------")
        row = board[r * 9:(r + 1) * 9]
        lines.append(" | ".join(" ".join(str(v) if v else "." for v in row[c:c + 3]) for c in (0, 3, 6)))
    return "\n".join(lines)

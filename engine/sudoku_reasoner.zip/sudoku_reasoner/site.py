"""The app as a static site, for an installable web app (APP_CONCEPT.md §8, U5).

``python -m sudoku_reasoner site OUT`` writes the UI from ``web/``, the package's
Python files as ``engine/sudoku_reasoner.zip`` and the pinned Pyodide core as
``pyodide/``, so ``web/js/worker.js`` runs the service in the browser; it
stamps ``js/engine.js`` to use that worker, and ``sw.js`` with the version and
every file, so the installed app keeps the whole site offline and replaces it
whole. Pyodide is fetched at build time
from its CDN, each file checked against its hash, and cached under ``build/pyodide``; it is never
committed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import urllib.request
import zipfile
from collections.abc import Sequence
from pathlib import Path

PACKAGE = Path(__file__).resolve().parent
WEB = PACKAGE / "web"
CACHE = PACKAGE.parent / "build" / "pyodide"
PYODIDE = "314.0.7"
PYODIDE_URL = f"https://cdn.jsdelivr.net/pyodide/v{PYODIDE}/full/"  # Pyodide's own CDN
# The core's files, each pinned by its hash.
PYODIDE_FILES = {
    "pyodide.mjs": "6f1d60f7bf529beb300f0f47983c921d3982363640ba20af0e38efdddbc66109",
    "pyodide.asm.mjs": "f7cdc8ece80678ceb712f8e65ebe6d3a83203a180c399865f49612a051693635",
    "pyodide.asm.wasm": "cc36e3cab04fdfc9a63ff13eb52eae2b911bf46c025cc7b281f394bd3de1d5e6",
    "python_stdlib.zip": "fa1957e5777068fc4f7437f96d860ae2fbe9c19732ba06c84e004ec16dd7dd7a",
    "pyodide-lock.json": "5dc2fc119108bc148c7457dc86e7675b5c87e1cafd420b9c34c1eaef7b36c010",
}
PYODIDE_NOTICE = f"""Pyodide {PYODIDE} (https://github.com/pyodide/pyodide), Mozilla Public License 2.0;
its source is at https://github.com/pyodide/pyodide/tree/{PYODIDE}.
python_stdlib.zip is CPython's standard library, Python Software Foundation License.
"""
STAMP = 'const SITE = { version: "", files: [] }; // written by site.py'
BUILT = "export const VERSION = null; // written by site.py: the built site's version, whose engine runs in the browser"


def pyodide(cache: Path = CACHE) -> Path:
    """The pinned Pyodide core's files, downloaded once and checked."""
    folder = cache / PYODIDE
    folder.mkdir(parents=True, exist_ok=True)
    for name, sha256 in PYODIDE_FILES.items():
        path = folder / name
        if path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == sha256:
            continue
        with urllib.request.urlopen(PYODIDE_URL + name, timeout=120) as response:  # noqa: S310 - a fixed https URL
            data = response.read()
        if hashlib.sha256(data).hexdigest() != sha256:
            raise RuntimeError(f"Pyodide {PYODIDE}'s {name} does not match its pinned hash")
        path.write_bytes(data)
    return folder


def package_zip(target: Path) -> None:
    """The package's Python files, importable once unpacked (no web files)."""
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(PACKAGE.rglob("*.py")):
            archive.write(path, Path(PACKAGE.name) / path.relative_to(PACKAGE))


def replace_line(path: Path, line: str, by: str) -> None:
    """``path`` with its stamp ``line`` replaced ``by`` another."""
    text = path.read_text(encoding="utf-8")
    if line not in text:
        raise RuntimeError(f"{path.name} has no line for the site to write")
    path.write_text(text.replace(line, by), encoding="utf-8")


def stamp(out: Path, version: str) -> None:
    """The engine in the browser with the version, and the service worker's
    version and the files it keeps."""
    replace_line(out / "js" / "engine.js", BUILT, f"export const VERSION = {json.dumps(version)};")
    worker = out / "sw.js"
    files = sorted(p.relative_to(out).as_posix() for p in out.rglob("*") if p.is_file() and p != worker)
    site = json.dumps({"version": version, "files": files}, separators=(",", ":"))
    replace_line(worker, STAMP, f"const SITE = {site};")


def built(folder: Path) -> bool:
    """Whether ``folder`` holds a site this module wrote (and so may replace)."""
    return (folder / "sw.js").is_file() and (folder / "engine" / "sudoku_reasoner.zip").is_file()


def build(out: Path, version: str = "local", cache: Path = CACHE) -> Path:
    """Write the site of ``version`` into ``out``: a new or empty folder, or a
    site written before, which it replaces; any other folder is refused."""
    if out.exists():
        if any(out.iterdir()) and not built(out):
            raise RuntimeError(f"{out} is neither empty nor a built site; refusing to replace it")
        shutil.rmtree(out)
    shutil.copytree(WEB, out, ignore=shutil.ignore_patterns("*.test.js"))
    (out / "engine").mkdir()
    package_zip(out / "engine" / "sudoku_reasoner.zip")
    shutil.copytree(pyodide(cache), out / "pyodide")
    (out / "pyodide" / "NOTICE.txt").write_text(PYODIDE_NOTICE, encoding="utf-8")
    stamp(out, version)
    return out


def main(argv: Sequence[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m sudoku_reasoner site", description="Build the app as a static site")
    p.add_argument("out", type=Path, help="the folder to write: new, empty, or a site built before (replaced)")
    p.add_argument("--version", default="local", help="the version the installed app keeps (default %(default)s)")
    args = p.parse_args(argv)
    print(f"Site {args.version} with Pyodide {PYODIDE}: {build(args.out, args.version)}")
    return 0
